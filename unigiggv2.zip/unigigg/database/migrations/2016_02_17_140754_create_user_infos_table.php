<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateUserInfosTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('user_infos', function (Blueprint $table) {
            $table->increments('user_info_id');
            $table->integer('user_id')->index();
            $table->string('fname');
            $table->string('lname');
            $table->text('address');
            $table->string('mobile');
            $table->string('facebookId');
            $table->string('NId');
            //$table->boolean('facebookId_v');
            $table->string('universityId');
            //$table->boolen('universityId_v');
            //$table->foreign('user_id')->references('user_id')->on('users')->onDelete('cascade');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('user_infos');
    }
}
