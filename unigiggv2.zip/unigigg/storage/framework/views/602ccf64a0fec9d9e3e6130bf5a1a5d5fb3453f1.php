<form class="" action="<?php echo e(url('skills',$skills->skill_id)); ?>" method="POST">
  <div class="well">
    <span class="text-danger">Every Field is required</span>
  </div>
  <div class="well">
    <p>
      Add a project
    </p>
    <small>upload the project to github/dropbox and share the link</small>
  </div>
  <?php echo csrf_field(); ?>

  <div class="form-group">
    <?php echo Form::label('skill_proof', 'Add Project URl:', ['class' => 'control-label']); ?>

    <?php echo Form::text('skill_proof', null, ['class' => 'form-control']); ?>

  </div>

  <?php if($errors->any()): ?>
    <div class="alert alert-danger">
      <?php foreach($errors->all() as $error): ?>
        <p><?php echo e($error); ?></p>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>



  <?php echo Form::submit('Add/Update', ['class' => 'btn btn-primary']); ?>

