<?php $__env->startSection('content'); ?>
  <div class="container ">
    <div class="row">
      <?php echo $__env->make('layouts.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <div class="col-md-6">
        <div class="panel panel-default">
          <div class="panel-heading"><a data-toggle="collapse" href="#collapse2">Basic Information</a></div>
            <div id="collapse2" class="panel-collapse collapse">
          <div class="panel-body">
            <?php echo Form::open(array('url' => '/userstore')); ?>

            <div class="md-col-6">

              <div class="form-group">
                <?php echo Form::label('fname', 'First Name', ['class' => 'control-label']); ?>

                <?php echo Form::text('fname', null, ['class' => 'form-control']); ?>

              </div>
              <div class="form-group">
                <?php echo Form::label('lname', 'Last Name', ['class' => 'control-label']); ?>

                <?php echo Form::text('lname', null, ['class' => 'form-control']); ?>

              </div>

              <div class="form-group">
                <?php echo Form::label('address', 'Address:', ['class' => 'control-label']); ?>

                <?php echo Form::text('address', null, ['class' => 'form-control']); ?>

              </div>
              <div class="form-group">
                <?php echo Form::label('mobile', 'Contact No :', ['class' => 'control-label']); ?>

                <?php echo Form::number('mobile', null, ['class' => 'form-control']); ?>

              </div>
              <div class="form-group">
                <?php echo Form::label('universityId', 'University ID:', ['class' => 'control-label']); ?>

                <?php echo Form::text('universityId', null, ['class' => 'form-control']); ?>

              </div>
              <div class="form-group">
                <?php echo Form::label('NId', 'NID:', ['class' => 'control-label']); ?>

                <?php echo Form::text('NId', null, ['class' => 'form-control']); ?>

              </div>
              <div class="form-group">
                <?php echo Form::label('facebookId', 'Facebook ID:', ['class' => 'control-label']); ?>

                <?php echo Form::text('facebookId', null, ['class' => 'form-control']); ?>

              </div>



              <?php echo Form::submit('Add', ['class' => 'btn btn-primary']); ?>


              <?php echo Form::close(); ?>



            </div>



          </div>
        </div>


          <?php echo $__env->make('student.skills', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <?php echo $__env->make('student.interest', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <?php echo $__env->make('student.hobby', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <?php echo $__env->make('student.education', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <?php echo $__env->make('student.image', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>



    </div>
    </div>
    </div>
  </div>


    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>