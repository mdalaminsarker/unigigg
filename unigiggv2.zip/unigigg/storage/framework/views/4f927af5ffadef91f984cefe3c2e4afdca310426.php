<div class="container">
  <div class="row">
    <?php echo $__env->make('layouts.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="col-md-10 ">
      <div class="panel panel-primary">
        <div class="panel-heading">Dashboard</div>

        <div class="panel-body">
          <h4 class="well">Welcome onboard <strong><?php echo e(Auth::user()->name); ?></strong>   </h4>
          <div class="col-md-5">

            <?php echo $__env->make('student.partials.userview.imageview', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

          </div>

          <br>

          <?php echo $__env->make('student.partials.userview.infoview', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <!-- Skills-->
          <?php if(count($skill)>0): ?>
            <?php echo $__env->make('student.partials.userview.skillview', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <?php endif; ?>


          <!-- interest-->
          <?php if(count($interest)>0): ?>
            <?php echo $__env->make('student.partials.userview.interestview', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <?php endif; ?>

          <?php if(count($hobbies)>0): ?>
            <?php echo $__env->make('student.partials.userview.hobbyview', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <?php endif; ?>

          <?php if(count($education)>0): ?>
            <?php echo $__env->make('student.partials.userview.eduview', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


          <?php endif; ?>
          <?php if(count($experiences)>0): ?>
            <?php echo $__env->make('student.partials.userview.expeview', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <?php endif; ?>

          <?php if(count($extracs)>0): ?>
            <?php echo $__env->make('student.partials.userview.excceview', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

          <?php endif; ?>

          <?php if(count($funs)>0): ?>
            <?php echo $__env->make('student.partials.userview.funview', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

          <?php endif; ?>

          <!--about your self ends-->
          <?php if(count($refs)>0): ?>
            <!-- references -->

            <?php echo $__env->make('student.partials.userview.referenceview', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <?php endif; ?>

        </div>

      </div>
    </div>





  </div>
</div>
