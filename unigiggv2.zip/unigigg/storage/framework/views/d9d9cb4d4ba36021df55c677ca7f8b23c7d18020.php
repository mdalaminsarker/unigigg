<div >


  <h4>Your Skills</h4>
  <button  class="btn btn-success" type="button" name="button">Verify</button>
  <?php foreach($skill as $skills): ?>
    <p>
      <table class="table table-condensed">
        <thead>
          <th>
            Skill
          </th>
          <th>
            Level
          </th>
          <th>
            Experience
          </th>

          <th>
            Show Skill Work
          </th>
          <th>
            Skill Proof
          </th>
          <th>
            Verification
          </th>
          <th>
            Delete
          </th>

        </thead>
        <tbody>
          <tr>
            <td>
              <?php echo e($skills->skill_name); ?>


            </td>
            <td>
              <?php echo e($skills->skill_level); ?>


            </td>
            <td>
              <?php echo e($skills->skill_experience); ?> Years
            </td>

            <td>
              <button type="submit" class="btn btn-primary" data-toggle="modal" data-target="#skillModal">
              <i class="fa fa-plus"></i> Add
              </button>
            </td>
            <?php if(count($skills->skill_proof)>0): ?>
            <td>
              <a href="<?php echo e($skills->skill_proof); ?>" target="_blank"><?php echo e($skills->skill_name); ?></a>
            </td>
            <?php else: ?>
              <td>
                Not added
              </td>
          <?php endif; ?>
          <?php if($skills->varified===0): ?>
            <td>
              <i class="fa fa-thumbs-o-down fa-3x"></i>
            </td>
          <?php else: ?>
            <td>
              <i class="fa fa-thumbs-o-up fa-3x"></i>
            </td>
          <?php endif; ?>
          <td>
            <form action="<?php echo e(url('skill',$skills->skill_id)); ?>" method="POST">
              <?php echo csrf_field(); ?>

              <button type="submit" class="btn btn-danger">
                <i class="fa fa-cross"></i> Delete
              </button>
            </form>
          </td>
          </tr>
        </tbody>
      </table>
    </p>

  <?php endforeach; ?>

</div>

<div class="modal fade" id="skillModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Update Information</h4>
      </div>
      <div class="modal-body">
        <?php echo $__env->make('student.partials.update.skill_proof', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>

      </div>
    </div>
  </div>
</div>
<!-- Modal ends -->
