

    <div class="panel panel-default">
      <div class="panel-heading"><a data-toggle="collapse" href="#collapse4">Add Degrees</a></div>
        <div id="collapse4" class="panel-collapse collapse">
          <div class="panel-body">

    <?php echo Form::open(array('url' => '/edustore')); ?>



    <div class="form-group">
      <?php echo Form::label('Degree_name', 'Degree Name:', ['class' => 'control-label']); ?>

      <?php echo Form::text('Degree_name', null, ['class' => 'form-control']); ?>

    </div>
    <div class="form-group">
      <?php echo Form::label('Degree_type', 'Tell Us Someting About Your Degree:', ['class' => 'control-label']); ?>

      <?php echo Form::text('Degree_type', null, ['class' => 'form-control']); ?>

    </div>
    <div class="form-group">
      <?php echo Form::label('Degree_start_date', 'Start Date:', ['class' => 'control-label']); ?>

      <?php echo Form::date('Degree_start_date', null, ['class' => 'form-control']); ?>

    </div>
    <div class="form-group">
      <?php echo Form::label('Degree_end_date', 'Passing Date:', ['class' => 'control-label']); ?>

      <?php echo Form::date('Degree_end_date', null, ['class' => 'form-control']); ?>

    </div>
    <div class="form-group">
      <?php echo Form::label('Degree_institute', 'Degree Institute:', ['class' => 'control-label']); ?>

      <?php echo Form::text('Degree_institute', null, ['class' => 'form-control']); ?>

    </div>
    <div class="form-group">
      <?php echo Form::label('Degree_result', 'Degree_result:', ['class' => 'control-label']); ?>

      <?php echo Form::number('Degree_result', null, ['class' => 'form-control']); ?>

    </div>
    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <?php foreach($errors->all() as $error): ?>
            <p><?php echo e($error); ?></p>
        <?php endforeach; ?>
    </div>
  <?php endif; ?>



    <?php echo Form::submit('Add', ['class' => 'btn btn-primary']); ?>


 <?php echo Form::close(); ?>


</div>
</div>
</div>
