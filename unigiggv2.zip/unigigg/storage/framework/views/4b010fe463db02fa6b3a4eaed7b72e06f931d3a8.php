<div class="">
  <hr>
  <br>
  <br>

  <h5>Education</h5>


  <table class="table table-striped table-condensed table-responsive">
    <thead class="text-primary">
      <tr>
        <th>
          Degree Name
        </th>
        <th>
          Degree Type
        </th>
        <th>
          Starting Date
        </th>
        <th>
          Passing Date
        </th>
        <th>
          Institute
        </th>
        <th>
          Result
        </th>
        <tr>
        </thead>
      </tbody>
      <?php foreach($education as $edu): ?>
        <tr>
          <td>
            <?php echo e($edu->Degree_name); ?>

          </td>
          <td>
            <?php echo e($edu->Degree_type); ?>

          </td>
          <td>
            <?php echo e($edu->Degree_start_date); ?>

          </td>
          <td>
            <?php echo e($edu->Degree_end_date); ?>

          </td>
          <td>
            <?php echo e($edu->Degree_institute); ?>

          </td>
          <td>
            <?php echo e($edu->Degree_result); ?>

          </td>
          <td>
              <button type="submit" class="btn btn-primary" data-toggle="modal" data-target="#myModal">
              <i class="fa fa-edit"></i>  Edit
              </button>

          </td>
          <td>
            <form action="<?php echo e(url('edudel',$edu->id)); ?>" method="POST">
              <?php echo csrf_field(); ?>

              <button type="submit" class="btn btn-danger">
                <i class="fa fa-trash"></i> Delete
              </button>
            </form>
          </td>
        </tr>
      </tbody>
    </table>

    <!-- Modal -->
    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title" id="myModalLabel">Update Information</h4>
          </div>
          <div class="modal-body">
            <?php echo $__env->make('student.partials.update.eduview', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>

          </div>
        </div>
      </div>
    </div>
    <!-- Modal ends -->
  <?php endforeach; ?>
</div>
