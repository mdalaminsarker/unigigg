<!DOCTYPE html>
<html lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>

  <title>CV</title>
  <style>
  #header {
    background-color:black;
    color:white;
    text-ah5gn:center;
    padding:5px;
  }
  #nav {
    h5ne-height:30px;
    background-color:#eeeeee;
    height:300px;
    width:100px;
    float:left;
    padding:5px;
  }
  #section {
    width:350px;
    float:left;
    padding:10px;
  }
  #footer {
    background-color:black;
    color:white;
    clear:both;
    text-ah5gn:center;
    padding:5px;
  }
  </style>


</head>
<body >

  <main  >
    <div id="details">
      <div id="invoice">
        <?php foreach($data as $user): ?>
          <h2><?php echo e($user->fname); ?> <?php echo e($user->lname); ?></h2>
          <h5><?php echo e($user->mobile); ?></h5>
          <h5 style="float:right;"><?php echo e($user->area); ?></h5>
        <?php endforeach; ?>
        <hr>

      </div>
    </div>




    <div  >
      <h3>Education</h3>

        <?php foreach($education as $edu ): ?>
          <table>
          <tr>


            <th>
              Degree Name
            </th>
            <th>
              Institute
            </th>
            <th>
              Passing Year
            </th>
            <th>
              Result
            </th>
            </tr>
            <tr>
          <td>
            <?php echo e($edu->Degree_name); ?>

          </td>
          <td>
              <?php echo e($edu->Degree_institute); ?>

          </td>
          <td>
            <?php echo e($edu->Degree_end_date); ?>

          </td>
          <td>
            <?php echo e($edu->Degree_result); ?> out of 4
          </td>
            </tr>

          </table>



        <?php endforeach; ?>


    </div>
    <hr>
    <h3>Skills</h3>
    <div style="float:right;">
      <?php foreach($skill as $skills ): ?>
        <?php echo e($skills->skill_name); ?> <br>

      <?php endforeach; ?>
    </div>












  </body>
  </html>
