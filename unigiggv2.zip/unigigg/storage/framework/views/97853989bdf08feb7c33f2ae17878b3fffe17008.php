

    <div class="panel panel-info">
      <div class="panel-heading">Skills</div>
      <div class="panel-body">

    <?php echo Form::open(array('url' => '/skillstore')); ?>



    <div class="form-group">
      <?php echo Form::label('skill_name', 'Skill Name:', ['class' => 'control-label']); ?>

      <?php echo Form::text('skill_name', null, ['class' => 'form-control']); ?>

    </div>
    <div class="form-group">
      <label for="skill_level" class="control-label">Skill Level</label>
      <select class="form-control" name="skill_level" id="select">
          <option value="Beginner">Beginner</option>
          <option value="Amature">Amature</option>
          <option value="Expert">Expert</option>
      </select>

    </div>

    <?php echo Form::submit('Add', ['class' => 'btn btn-primary']); ?>


 <?php echo Form::close(); ?>


</div>
</div>
</div>
