<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
      <?php echo $__env->make('layouts.emmenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="col-md-10 ">
            <div class="panel panel-info">
                <div class="panel-heading">Employer Dashboard</div>

                <div class="panel-body">
                  <div class="jumbotron">


                  <img src="https://minions-funmobility.netdna-ssl.com/wp-content/uploads/2015/05/signup-after-img1.jpg" alt="Pro Pic" height="200px" width="200px"/>

                    Welcome <strong class="primary"><?php echo e(Auth::guard('em_users')->user()->em_fname); ?> <?php echo e(Auth::guard('em_users')->user()->em_lname); ?>

                    </strong> The Recruiter
                  </div>

                  <div class="Jumbotron">




                  </div>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.employerapp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>