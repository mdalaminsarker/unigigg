<?php $__env->startSection('content'); ?>

        <div class="container">
            <div class="row "style="height:325px; background:url(http://www.simplyzaspy.com/wp-content/uploads/2015/02/2.jpg);">
              <h1 style="color:white;">Getting a job is easy now</h1>

            </div>
          </div>
  <?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>