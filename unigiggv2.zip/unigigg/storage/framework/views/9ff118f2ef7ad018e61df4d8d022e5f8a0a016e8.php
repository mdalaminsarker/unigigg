<?php $__env->startSection('content'); ?>
  <div class="container ">
    <div class="row">
      <?php echo $__env->make('layouts.emmenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <div class="col-md-6">
        <div class="well">
          <h4 class="text-info">Jobs Posted by You</h4>
        </div>
        <div class="col-md-8">
          <?php if(count($postedjobs)>0): ?>

              <?php foreach($postedjobs as $jobs): ?>



                  <div class="panel panel-primary">
                    <div class="panel-heading">
                      <h3 class="panel-title"><?php echo e($jobs->job_name); ?></h3>
                    </div>
                    <div class="panel-body">
                      <Type: <?php echo e($jobs->job_type); ?></li>
                      <li>Location: <?php echo e($jobs->job_location); ?></li>
                      <li>Salary: <?php echo e($jobs->job_salary); ?></li>
                      <div class="well">
                        Description: <?php echo e($jobs->job_description); ?>

                        <?php echo e($jobs->job_reqs); ?>

                      </div>
                    </div>

                    <div class="panel-footer">
                      <form action="<?php echo e(url('postjobs',$jobs->job_id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>

                        <button type="submit" class="btn btn-danger btn-sm btn-block-sm">
                          <i class="fa fa-user"></i> Remove
                        </button>
                      </form>

                    </div>
                  </div>
              

              <?php endforeach; ?>

            <?php endif; ?>



        </div>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>