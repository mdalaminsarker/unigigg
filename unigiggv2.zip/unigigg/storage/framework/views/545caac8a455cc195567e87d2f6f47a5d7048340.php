<div >


  <h4>Your interest</h4>

  <?php foreach($interest as $interests): ?>
    <table class="table table-striped">
      <thead>
        <th>
          Interests
        </th>
        <th>
          Remove
        </th>
      </thead>
      <tbody>
        <tr>
          <td>
            <?php echo e($interests->interest_name); ?>

          </td>
          <td>
            <form action="<?php echo e(url('interest',$interests->interest_id)); ?>" method="POST">
              <?php echo csrf_field(); ?>

              <button type="submit" class="btn btn-danger ">
                <i class="fa fa-cross"></i> Delete
              </button>
            </form>

          </td>
        </tr>
      </tbody>
    </table>


  <?php endforeach; ?>

</div>
