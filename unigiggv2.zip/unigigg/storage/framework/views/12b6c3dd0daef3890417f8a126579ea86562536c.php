<?php $__env->startSection('content'); ?>
  <div class="container ">
    <div class="row">
      <?php echo $__env->make('layouts.emmenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <div class="col-md-10">
        <div class="well">
          <h4 class="text-info">Shortlisted Candidates</h4>

        </div>


        <?php foreach( $shortlisted as $shortlist ): ?>
        <?php if($shortlist->user_id===Auth::user()->id): ?>
          <?php if($shortlist->job_name===$shortlist->job_name): ?>

        <table class="table table-striped ">
          <thead>
            <th>
              Candidate Name
            </th>
            <th>
              Shortlisted For
            </th>
            <th>
              Profile View
            </th>
            <th>
              Remove
            </th>
            <th>
              Finalize
            </th>
          </thead>
          <tbody>
            <tr>
              <td>
                <?php echo e($shortlist->fname); ?> <?php echo e($shortlist->lname); ?>

              </td>
              <td>
                <?php echo e($shortlist->job_name); ?>

              </td>
              <td>

                <button type="button" name="button">View Profile</button>
              </td>

              <td>
                <form action="<?php echo e(url('shortlist',$shortlist->em_shortlist_id)); ?>" method="POST">
                  <?php echo csrf_field(); ?>

                  <button type="submit" class="btn btn-info btn-sm btn-block-sm">
                    <i class="fa fa-user"></i> Remove
                  </button>
                </form>
              </td>
              <td>
                <?php if($shortlist->finalized===1): ?>
                  <p>
                    Finalized
                  </p>
                <?php else: ?>
                <form action="<?php echo e(url('finalize',$shortlist->em_shortlist_id)); ?>" method="POST">
                  <?php echo csrf_field(); ?>

                  <button type="submit" class="btn btn-success btn-sm btn-block-sm">
                    <i class="fa fa-check"></i>Finalize
                  </button>
                </form>
              <?php endif; ?>
              </td>

            </tr>
          </tbody>

        <?php endif; ?>
        <?php endif; ?>
        <?php endforeach; ?>

        </table>


      </div>
    </div>
  </div>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>