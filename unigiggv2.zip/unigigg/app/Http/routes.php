<?php

/*
|--------------------------------------------------------------------------
| Routes File
|--------------------------------------------------------------------------
|
| Here is where you will register all of the routes in an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

Route::get('/', function () {
    return view('welcome');
});

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| This route group applies the "web" middleware group to every route
| it contains. The "web" middleware group is defined in your HTTP
| kernel and includes session state, CSRF protection, and more.
|
*/

Route::group(['middleware' => ['web']], function () {
    //
    Route::get('/employer/login','EmAuth\AuthController@showLoginForm');
    Route::post('/employer/login','EmAuth\AuthController@login');
    Route::get('/employer/logout','EmAuth\AuthController@logout');
    //Registration
    Route::get('employer/register', 'EmAuth\AuthController@showRegistrationForm');
    Route::post('employer/register', 'EmAuth\AuthController@register');

    Route::get('/employer', 'EmAuth\EmployerController@index');
});

Route::group(['middleware' => 'web'], function () {
    Route::auth();

    Route::get('/home', 'HomeController@index');
    Route::get('/userinfo', 'UserInfoController@create');
    Route::post('/skillstore', 'SkillController@store');
    Route::post('/intereststore', 'InterestController@store');
    Route::post('/hobbystore', 'HobbyController@store');
    Route::post('/edustore', 'EducationController@store');
    Route::post('/imagestore', 'ImageController@store');
    Route::post('/userstore', 'UserInfoController@store');
});
