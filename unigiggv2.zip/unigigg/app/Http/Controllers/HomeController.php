<?php

namespace App\Http\Controllers;

use App\Http\Requests;
use DB;
use Illuminate\Http\Request;
//models
use App\Model\Student\UserInfo;

use App\Model\Student\Skills;
use App\Model\Student\Hobbies;
use App\Model\Student\Education;
use App\Model\Student\Interest;
use App\Model\Student\User;
class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

      $infos = Userinfo::orderBy('created_at', 'asc')->get();
      $skill = Skills::orderBy('created_at', 'asc')->get();
      $interest = Interest::orderBy('created_at', 'asc')->get();
      $hobbies = Hobbies::orderBy('created_at', 'asc')->get();
      $education = Education::orderBy('created_at', 'asc')->get();


    return view('home', [
        'infos' => $infos,
        'skill' =>$skill,
        'interest' => $interest,
        'hobbies' => $hobbies,
        'education' =>$education,
        
    ]);

    }
}
