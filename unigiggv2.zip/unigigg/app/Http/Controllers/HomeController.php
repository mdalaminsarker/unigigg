<?php

namespace App\Http\Controllers;

use App\Http\Requests;
use DB;
use Illuminate\Http\Request;
use App\Model\Student\UserInfo;
use App\Model\Student\User;
class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

      $infos = Userinfo::orderBy('created_at', 'asc')->get();

    return view('home', [
        'infos' => $infos
    ]);

    }
}
