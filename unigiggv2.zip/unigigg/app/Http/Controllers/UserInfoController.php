<?php
namespace App\Http\Controllers;

    use Illuminate\Http\Request;
    use App\Model\Student\UserInfo;
    use App\Http\Requests;
    use App\Http\Controllers\Controller;

    class UserInfoController extends Controller
    {
      //
      public function __construct()
      {
        $this->middleware('auth');
      }

      public function create()
      {
        return view('student.userinfo');

      }
      public function store(Request $request)
      {

            $this->validate($request, [
              'fname' => 'required|max:255|min:4',
              'lname' => 'required|max:255|min:4',
              'address' => 'required|max:255|min:10',
              'mobile' => 'required|max:14|min:11',
              'universityId' => 'required|max:20',
              'NId' => 'required|max:17|min:13',
              'facebookId' => 'required',
            ]);
        
          $request->user()->userinfo()->create([
              'fname' => $request->fname,
              'lname' => $request->lname,
              'address' => $request->address,
              'mobile' => $request->mobile,
              'universityId' => $request->universityId,
              'NId' => $request->NId,
              'facebookId' => $request->facebookId,
            ]);

            return redirect('home');
      }

    }
