<?php

namespace App\Http\Controllers\EmAuth;

use App\Model\Employer\EmUser;
use Validator;
use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\ThrottlesLogins;
use Illuminate\Foundation\Auth\AuthenticatesAndRegistersUsers;

class AuthController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Registration & Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the registration of new users, as well as the
    | authentication of existing users. By default, this controller uses
    | a simple trait to add these behaviors. Why don't you explore it?
    |
    */

    use AuthenticatesAndRegistersUsers, ThrottlesLogins;

    /**
     * Where to redirect users after login / registration.
     *
     * @var string
     */

     protected $redirectTo = '/employer';
     protected $guard = 'em_users';
     public function showLoginForm()
     {
         if (view()->exists('auth.authenticate')) {
             return view('auth.authenticate');
        }

         return view('employer.auth.login');
     }
     public function showRegistrationForm()
     {
         return view('employer.auth.register');
     }

    /**
     * Create a new authentication controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest', ['except' => 'logout']);
    }

    /**
     * Get a validator for an incoming registration request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    protected function validator(array $data)
    {
        return Validator::make($data, [
            'em_fname' => 'required|max:50|min:3',
            'em_lname' => 'required|max:50|min:3',
            'email' => 'required|email|max:255|unique:em_users',
            'password' => 'required|confirmed|min:6',
        ]);
    }

    /**
     * Create a new user instance after a valid registration.
     *
     * @param  array  $data
     * @return User
     */
    protected function create(array $data)
    {
        return EmUser::create([
            'em_fname' => $data['em_fname'],
            'em_lname' => $data['em_lname'],
            'email' => $data['email'],
            'password' => bcrypt($data['password']),
        ]);
    }
}
