<?php

namespace App\Http\Controllers\EmAuth;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;


class EmployerController extends Controller
{
    //
    public function __construct()
    {
       $this->middleware('em_users');
    }
  public function index()
  {
       return view('employer.emdashboard');
   }
}
