<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Carbon\Carbon;
use App\Http\Requests;
use Validator;
use App\Model\Student\Image;
use App\Http\Controllers\Controller;
use Input;

class ImageController extends Controller
{
    //
    public function __construct()
    {
      $this->middleware('auth');
    }

    public function store(Request $request){
  		// Store records process
            $image = new Image();
            $this->validate($request, [
              'image' => 'required',
             ]);
             if($request->hasFile('image')) {
                     $file = Input::file('image');
                     //getting timestamp
                     $timestamp = str_replace([' ', ':'], '-', Carbon::now()->toDateTimeString());

                     $name = $timestamp. '-' .$file->getClientOriginalName();

                     $image->filePath = $name;

                     $file->move(public_path().'/images/', $name);
                 }
             $image->save();

             return $this->create()->with('success', 'Image Uploaded Successfully');
        }
}
