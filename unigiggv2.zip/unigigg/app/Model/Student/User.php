<?php

namespace App\Model\Student;

use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'password','institute','uEndDate',
    ];

    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    public function userinfo()
    {
      return $this->hasOne(UserInfo::class);
    }
    public function skills()
    {
       return $this->hasMany(Skills::class);
    }
    public function interests()
    {
       return $this->hasMany(Interest::class);
    }
    public function hobbies()
    {
       return $this->hasMany(Hobbies::class);
    }
    public function education()
    {
       return $this->hasMany(Education::class);
    }
    public function images()
    {
       return $this->hasOne(Image::class);
    }
}
