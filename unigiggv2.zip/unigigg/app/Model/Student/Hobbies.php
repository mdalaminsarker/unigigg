<?php

namespace App\Model\Student;

use Illuminate\Database\Eloquent\Model;

class Hobbies extends Model
{
    //
}
