<?php

namespace App\Model\Student;

use Illuminate\Database\Eloquent\Model;

class UserInfo extends Model
{
    //
    protected $fillable = [
      'fname','lname','address','mobile','facebookId','NId','universityId',
    ];

    public function user()
   {
       return $this->belongsTo(User::class);
   }
}
