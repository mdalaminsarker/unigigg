<?php

namespace App\Model\Student;

use Illuminate\Database\Eloquent\Model;

class Education extends Model
{
    //
}
