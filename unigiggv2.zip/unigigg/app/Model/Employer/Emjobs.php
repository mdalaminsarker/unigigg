<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Emjobs extends Model
{
    //
}
