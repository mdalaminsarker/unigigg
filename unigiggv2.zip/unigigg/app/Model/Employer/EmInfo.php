<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EmInfo extends Model
{
    //
    protected $table = 'em_infos';
    protected $fillable = [
    'company_name',
    'company_logo',
    'company_type',
    'company_size',
    'company_description',
 ];
   public function emuser()
   {

        return $this->belongsTo(EmUser::class);

   }

}
