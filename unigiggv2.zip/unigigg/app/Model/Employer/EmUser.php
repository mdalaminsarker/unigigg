<?php

namespace App\Model\Employer;

use Illuminate\Foundation\Auth\User as Authenticatable;

class EmUser extends Authenticatable
{
    //

    protected $fillable = [
        'em_fname', 'em_lname','email', 'password',
    ];
    protected $hidden = [
        'password', 'remember_token',
    ];
}
