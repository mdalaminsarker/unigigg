@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
    @include('layouts.menu')

        <div class="col-md-8 col-md-offset-1">
            <div class="panel panel-primary">
                <div class="panel-heading">Dashboard</div>

                <div class="panel-body">
                    <h4>Welcome {{Auth::user()->name}} !! </h4>
                    <p>
                    <strong>Institute : </strong>{{Auth::user()->institute}}  <br><strong>Passing Year :</strong> {{Auth::user()->uEndDate}}
                  </p>
                    <p>
                      @foreach ($infos as $users)
                        <p>
                          <h6>Phone : {{$users->mobile}}</h6>
                          <h6>Address : {{$users->address}}</h6>
                          <h6>NID : {{$users->NId}}</h6>
                        </p>
                        <h5>University ID :{{$users->universityId}}</h5>
                        Facebook: Id:
                        <a href="{{$users->facebookId}}" target="_blank">{{$users->fname}}</a>
                      @endforeach
                    </p>

              </div>
              <div class="md col-4">
                <div class="container">
                <ul class="nav nav-tabs">
                      <li class="active"><a href="#home" data-toggle="tab">Home</a></li>
                      <li><a href="#profile" data-toggle="tab">Profile</a></li>

                      <li class="dropdown">
                        <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                          Dropdown <span class="caret"></span>
                        </a>
                        <ul class="dropdown-menu">
                          <li><a href="#dropdown1" data-toggle="tab">Action</a></li>
                          <li class="divider"></li>
                          <li><a href="#dropdown2" data-toggle="tab">Another action</a></li>
                        </ul>
                      </li>
                    </ul>

                    <div id="myTabContent" class="tab-content">
                      <div class="tab-pane fade active in" id="home">
                        <p>Raw denim you probably haven't heard of them jean shorts Austin. <br>
                          Nesciunt tofu stumptown aliqua, retro synth master cleanse. Mustache cliche tempor,<br>
                           williamsburg carles vegan helvetica. Reprehenderit butcher retro keffiyeh dreamcatcher<br>
                            synth. Cosby sweater eu banh mi, qui irure terry richardson ex squid. Aliquip placeat<br>
                             salvia cillum iphone. Seitan aliquip quis cardigan american apparel, <br>
                             butcher voluptate nisi qui.</p>
                      </div>
                      <div class="tab-pane fade" id="profile">
                        <p>Food truck fixie locavore, accusamus mcsweeney's marfa nulla single-origin coffee squid. <br>
                          Exercitation +1 labore velit, blog sartorial PBR <br>
                          leggings next level wes anderson artisan four loko farm-to-table craft beer twee.<br>
                           Qui photo booth letterpress, commodo enim craft beer mlkshk aliquip jean shorts<br> ullamco ad vinyl cillum PBR
                           . Homo nostrud organic, assumenda labore aesthetic magna delectus mollit.</p>
                      </div>
                      <div class="tab-pane fade" id="dropdown1">
                        <p>Etsy mixtape wayfarers, ethical wes anderson tofu before they sold out mcsweeney's <br>
                          organic lomo retro fanny pack lo-fi farm-to-table readymade. Messenger bag gentrify <br>
                          pitchfork tattooed craft beer, iphone skateboard locavore carles etsy salvia banksy <br>
                          hoodie helvetica. DIY synth PBR banksy irony. Leggings gentrify squid 8-bit cred pitchfork.</p>
                      </div>
                      <div class="tab-pane fade" id="dropdown2">
                        <p>Trust fund seitan letterpress, keytar raw denim keffiyeh etsy art party before they <br>sold
                           out master cleanse gluten-free squid scenester freegan cosby sweater. Fanny pack portland seitan DIY,<br>
                            art party locavore wolf cliche high life echo park Austin. Cred vinyl keffiyeh DIY salvia PBR, <br>
                            banh mi before they sold out farm-to-table VHS viral locavore cosby sweater.</p>
                      </div>
                    </div>
                    </div>
        </div>
    </div>
</div>
@endsection
