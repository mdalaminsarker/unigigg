@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
    @include('layouts.menu')

        <div class="col-md-8 col-md-offset-1">
            <div class="panel panel-primary">
                <div class="panel-heading">Dashboard</div>

                <div class="panel-body">
                    <h4>Welcome {{Auth::user()->name}} !! </h4>
                    <img src="{!! '/images/default.png' !!}" alt="Pro Pic" height="100px" width="100px"/>
                    <p>
                    <strong>Institute : </strong>{{Auth::user()->institute}}  <br><strong>Passing Year :</strong> {{Auth::user()->uEndDate}}
                  </p>



                    <p>
                      @foreach ($infos as $users)
                        <p>
                          <h6>Phone : {{$users->mobile}}</h6>
                          <h6>Address : {{$users->address}}</h6>
                          <h6>NID : {{$users->NId}}</h6>
                        </p>
                        <h5>University ID :{{$users->universityId}}</h5>
                        Facebook: Id:
                        <a href="{{$users->facebookId}}" target="_blank">{{$users->fname}}</a>
                      @endforeach
                    </p>
                    <!-- Skills-->

                      <h4>Your Skills</h4>
                    @foreach ($skill as $skills)


                    <p>
                      <ul>
                        <li>{{$skills->skill_name}}--->{{$skills->skill_level}}</li>
                      </ul>
                    </p>

                    @endforeach

                    <!-- interest-->
                      <h4>Your interest</h4>
                    @foreach ($interest as $interests)
                    <p>
                      <ul>
                        <li>{{$interests->interest_name}}</li>
                      </ul>
                    </p>

                    @endforeach

                    <!-- Hobbies-->
                  <h4>Your Hobbies</h4>
                  @foreach ($hobbies as $hobby)
                    <p>
                    <ul>
                      <li>{{$hobby->hobbies_name}} --> {{$hobby->hobbies_related_work}}</li>
                    </ul>
                  </p>

                  @endforeach
                  <h5>Education</h5>


                    <table class="table table-striped table-hover">
                      <thead>
                        <tr>
                        <th>
                          Degree Name
                        </th>
                        <th>
                          Degree Type
                        </th>
                        <th>
                          Starting Date
                        </th>
                        <th>
                          Passing Date
                        </th>
                        <th>
                          Institute
                        </th>
                        <th>
                          Result
                        </th>
                        <tr>
                        </thead>
                      </tbody>
                        @foreach ($education as $edu)
                        <tr>
                          <td>
                            {{$edu->Degree_name}}
                          </td>
                          <td>
                            {{$edu->Degree_type}}
                          </td>
                          <td>
                            {{$edu->Degree_start_date}}
                          </td>
                          <td>
                            {{$edu->Degree_end_date}}
                          </td>
                          <td>
                            {{$edu->Degree_institute}}
                          </td>
                          <td>
                            {{$edu->Degree_result}}
                          </td>
                        </tr>
                      </tbody>
                    </table>

                  @endforeach
                </div>

              </div>
            </div>





</div>
</div>
@endsection
