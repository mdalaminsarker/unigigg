@extends('layouts.app')

@section('content')

        <div class="container">
            <div class="row "style="height:325px; background:url(http://www.simplyzaspy.com/wp-content/uploads/2015/02/2.jpg);">
              <h1 style="color:white;">Getting a job is easy now</h1>

            </div>
          </div>
  @include('layouts.footer')
  @endsection
