<div >


  <h4>Your interest</h4>

  @foreach ($interest as $interests)
    <table class="table table-striped">
      <thead>
        <th>
          Interests
        </th>
        <th>
          Remove
        </th>
      </thead>
      <tbody>
        <tr>
          <td>
            {{$interests->interest_name}}
          </td>
          <td>
            <form action="{{url('interest',$interests->interest_id)}}" method="POST">
              {!! csrf_field() !!}
              <button type="submit" class="btn btn-danger ">
                <i class="fa fa-cross"></i> Delete
              </button>
            </form>

          </td>
        </tr>
      </tbody>
    </table>


  @endforeach

</div>
