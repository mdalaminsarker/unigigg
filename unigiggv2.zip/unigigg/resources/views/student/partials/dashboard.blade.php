<div class="container">
  <div class="row">
    @include('layouts.menu')

    <div class="col-md-10 ">
      <div class="panel panel-primary">
        <div class="panel-heading">Dashboard</div>

        <div class="panel-body">
          <h4 class="well">Welcome onboard <strong>{{Auth::user()->name}}</strong>   </h4>
          <div class="col-md-5">

            @include('student.partials.userview.imageview')

          </div>

          <br>

          @include('student.partials.userview.infoview')
          <!-- Skills-->
          @if(count($skill)>0)
            @include('student.partials.userview.skillview')
          @endif


          <!-- interest-->
          @if(count($interest)>0)
            @include('student.partials.userview.interestview')
          @endif

          @if(count($hobbies)>0)
            @include('student.partials.userview.hobbyview')
          @endif

          @if(count($education)>0)
            @include('student.partials.userview.eduview')


          @endif
          @if(count($experiences)>0)
            @include('student.partials.userview.expeview')
          @endif

          @if(count($extracs)>0)
            @include('student.partials.userview.excceview')

          @endif

          @if(count($funs)>0)
            @include('student.partials.userview.funview')

          @endif

          <!--about your self ends-->
          @if(count($refs)>0)
            <!-- references -->

            @include('student.partials.userview.referenceview')
          @endif

        </div>

      </div>
    </div>





  </div>
</div>
