<div class="col-md-2">
  <ul class="list-group">
    <li class="list-group-item">
      <a href="{{url('employer')}}"><strong>Dashboard</strong></a>

    </li>
    <li class="list-group-item">
      <a href="{{url('employerinfo')}}"><strong>Build Profile</strong></a>

    </li>
    <li class="list-group-item">
      <a href="#"><strong>Post Job</strong></a>

    </li>
  </li>
  <li class="list-group-item">
    <a href="#"><strong>Shortlisted</strong></a>

  </li>
  <li class="list-group-item">
    <a href="#"><strong>Posted Jobs</strong></a>
  </ul>
</div>
