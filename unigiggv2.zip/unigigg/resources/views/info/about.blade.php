@extends('layouts.app')

@section('content')
  <div class="container">
    <div class="row">
      <div class="pull-center">
        <h2>About <strong class="text-primary">Us</strong></h2>
      </div>
      <div class="col-md-10">

        <p>
          <strong><span class="text-primary">U</span>nigigg</strong> is a youth employment platform <br>
          It was created specifically to show that young people have a range of work skills often hidden in the things they do every day and to give them the language of employers to describe those skills. We have designed unigigg to create rich, dynamic profiles that will give employers a meaningful insight into the skills that its users have.
        </p>
        
        <p>
          <strong>It helps users to:</strong>
          <li>Identify their professional work skills</li>
          <li>Build a dynamic profile showing their primary skill groups</li>
          <li>Create a portfolio of online content showing their skills.</li>
          <li>Help jobseekers find better offers, super fast</li>

          <strong>It helps employers to:</strong>

          <li>Identify proactive new employees with specific skills</li>
          <li>Expedite the hiring process</li>
          </p>

        </div>
        <br>

        <!-- Team -->
        <div class="col-md-10" >
          <h2 class="text-primary">Team</h2>
        </div>
        <div class="col-md-10">
          <hr>
          <div >
            <img  src="{!!'/images/tayef.jpg' !!}" alt="" height="200px" width="200px" style="border-radius:50%;" />

            <div class="pull-right">
              <h4>MD AL Amin Sarker</h4>
              <h5>Co-Founder</h5>
              <p>
                Every Problem is an opportunity to a community, We have<br> lots so lets solve
              </p>
              <p>
                <i class="fa fa-facebook"></i>
              </p>
            </div>

          </div>


        </div>

        <div class="col-md-10">
          <hr>
          <div >
            <img  src="{!!'/images/rehan.jpg' !!}" alt="" height="200px" width="200px" style="border-radius:50%;" />

            <div class="pull-right">
              <h4>Rehanul Islam</h4>
              <h5>Co-Founder</h5>
              <p>
                Perks of having your close friend's sister getting married.
              </p>
              <p>
                <i class="fa fa-facebook"></i>
              </p>
            </div>

          </div>


        </div>

      </div>

    </div>
    <hr>
    @include('layouts.footer')
  @endsection
