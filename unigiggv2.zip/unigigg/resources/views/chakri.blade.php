@extends('layouts.app')

@section('content')
<div class="container">
  <div class="row">

    @include('layouts.menu')

    <div class="col-md-8">


    @if(count($jobs)>0)
    @foreach($jobs as $job)
      <br>
        <div class="panel panel-primary">
          <div class="panel-heading">
            <h3 class="panel-title">{{$job->job_name}}</h3>
          </div>
          <div class="panel-body">
            Type: {{$job->job_type}}
            <li>Location: {{$job->job_location}}</li>
            <li>Salary: {{$job->job_salary}}</li>

              <p>
                <strong>Description: </strong>{{$job->job_description}}
              </p>
              <p>
                <strong>Requirements: </strong> {{$job->job_reqs}}
              </p>
              <p>
              <strong>  Additional Requirements: </strong>  {{$job->job_reqs_additional}}
              </p>
              <p>
              <strong>  Application Deadline: </strong>  {{$job->job_last_date_application}}
              </p>





        </div>
        <div class="panel-footer">

                <div class="well">
                  <strong>Posted By {{$job->company_name}}</strong>

                  <!-- Check if its recruter or not-->
                @if(Auth::user()->type===1)
                <form class="form-control" action="{{url('apply')}}" method="post">
                  {!! csrf_field() !!}
                  <div class="form-group">
                      <input type="hidden" name="applied_for_job_id" value="{{$job->job_id}}">
                  </div>
                  <div class="form-group">
                    <input type="hidden" name="user_id" value="{{Auth::user()->id}}">
                  </div>

                  <button type="submit" name="button" class="btn btn-success">Apply</button>


                </form>
              @endif
              </div>
        </div>
          @endforeach
        @endif

    </div>
        </div>
    </div>
      </div>
@endsection
