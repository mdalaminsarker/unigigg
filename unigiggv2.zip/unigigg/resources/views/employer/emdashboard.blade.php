@extends('layouts.employerapp')

@section('content')
<div class="container">
    <div class="row">
      @include('layouts.emmenu')
        <div class="col-md-10 ">
            <div class="panel panel-info">
                <div class="panel-heading">Employer Dashboard</div>

                <div class="panel-body">
                  <div class="jumbotron">


                  <img src="https://minions-funmobility.netdna-ssl.com/wp-content/uploads/2015/05/signup-after-img1.jpg" alt="Pro Pic" height="200px" width="200px"/>

                    Welcome <strong class="primary">{{ Auth::guard('em_users')->user()->em_fname }} {{ Auth::guard('em_users')->user()->em_lname }}
                    </strong> The Recruiter
                  </div>

                  <div class="Jumbotron">




                  </div>

                </div>
            </div>
        </div>
    </div>
</div>
@endsection
