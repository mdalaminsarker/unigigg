@extends('layouts.employerapp')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">Employer Dashboard</div>

                <div class="panel-body">
                    Welcome <strong class="primary">{{ Auth::guard('em_users')->user()->em_fname }} </strong>Tumi to Admin bolo ki korte chao :D

                </div>
            </div>
        </div>
    </div>
</div>
@endsection
