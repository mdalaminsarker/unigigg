<?php

namespace App\Http\Controllers;

use App\Http\Requests;
use DB;
use Illuminate\Http\Request;
//models
use App\Model\Student\UserInfo;
use App\Model\Student\Experience;
use App\Model\Student\ExtraCur;
use App\Model\Student\Skills;
use App\Model\Student\Hobbies;
use App\Model\Student\Education;
use App\Model\Student\Interest;
use App\Model\Student\User;
use App\Model\Student\FunFacts;
class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {

      $infos = Userinfo::where('user_id', $request->user()->id)->get();
      $skill = Skills::where('user_id', $request->user()->id)->get();
      $interest = Interest::where('user_id', $request->user()->id)->get();
      $hobbies = Hobbies::where('user_id', $request->user()->id)->get();
      $education = Education::where('user_id', $request->user()->id)->get();
      $experiences = Experience::where('user_id', $request->user()->id)->get();
      $extracs = ExtraCur::where('user_id', $request->user()->id)->get();
      $funs = FunFacts::where('user_id', $request->user()->id)->get();


    return view('home', [
        'infos' => $infos,
        'skill' =>$skill,
        'interest' => $interest,
        'hobbies' => $hobbies,
        'education' =>$education,
        'experiences'=>$experiences,
        'extracs'=>$extracs,
        'funs'=>$funs,

    ]);

    }
}
