<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Model\Student\StudentApplied;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use DB;
use App\Model\Student\UserInfo;
use App\Model\Student\Experience;
use App\Model\Student\ExtraCur;
use App\Model\Student\Skills;
use App\Model\Student\Hobbies;
use App\Model\Student\Education;
use App\Model\Student\Interest;
use App\Model\Student\User;
use App\Model\Student\FunFacts;
use App\Model\Student\Image;
use App\Model\Student\EmInfo;
use App\Model\Student\Jobs;

class ApplyController extends Controller
{
    //
    public function __construct()
    {
      $this->middleware('auth');
    }
    //Student applied

    public function store(Request $request)
    {

      $input = $request->all();

      StudentApplied::create($input);

      return redirect('/home');
    }



    public function showApplied()
    {
      $applied = DB::table('student_applieds')
            ->join('user_info', 'student_applieds.user_id', '=', 'user_info.user_id')
            ->join('jobs', 'student_applieds.applied_for_job_id', '=', 'jobs.job_id')
            ->select('student_applieds.*', 'user_info.*','jobs.job_id', 'jobs.job_name','jobs.user_id')
            ->get();


      return view('employer.applied', [
        'applied'=>$applied,

      ]);

    }
    public function studentemview($id)
    {
      $profile = UserInfo::where('user_id','=', $id)->get();
      $skill = Skills::where('user_id','=', $id)->get();
      $education = Education::where('user_id','=', $id)->get();
      return view('student.studentemview', [
        'profile'=>$profile,
        'skill'=>$skill,
        'education'=> $education,


      ]);


    }
}
