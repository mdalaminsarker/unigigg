<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Model\Student\User;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class OddJobsController extends Controller
{
    //

    public function createPdf(){

      $data = $this->getData();
          $date = date('Y-m-d');
          $invoice = "2222";
          $view =  \View::make('invoice', compact('data', 'date', 'invoice'))->render();
          $pdf = \App::make('dompdf.wrapper');
          $pdf->loadHTML($view)->setPaper('a4', 'potrait');
          return $pdf->stream('invoice');
    }
    public function getData()
   {
       $data = User::all();
       return $data;
   }
}
