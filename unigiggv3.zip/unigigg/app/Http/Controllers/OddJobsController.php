<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Model\Student\OddJobs;

use App\Http\Requests;
use App\Http\Controllers\Controller;

class OddJobsController extends Controller
{
    //
    public function __construct()
    {
      $this->middleware('auth');
    }

    public function index(){

      $oddjobs = OddJobs::all();
      return view('jobs.oddjobs',[
        'oddjobs'=> $oddjobs,
      ]);

    }
    public function postjobs()
    {
        return view('jobs.postoddjobs');
    }
    public function empostjobs()
    {
        return view('jobs.empostoddjobs');
    }
    public function postjob(Request $request)
    {
      $this->validate($request, [
        'title'         => 'required|min:3|max:255',
        'type'          => 'required',
        'description'   => 'required',
        'offering'      => 'required',
        'area'          => 'required',
        'university'    => 'min:5|max:50',


      ]);

    $request->user()->oddjobs()->create([
          'title'=> $request->title,
          'type' => $request->type,
          'description' => $request->description,
          'offring' => $request->offering,
          'area' => $request->area,
          'university' => $request->university,

      ]);

      return redirect('/home');

    }

}
