<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Model\Student\Hobbies;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class HobbyController extends Controller
{
    //
    public function __construct()
    {
      $this->middleware('auth');
    }

    public function store(Request $request)
    {
        $this->validate($request, [
            'hobbies_name' => 'required|max:20',
            'hobbies_related_work' => 'required',

        ]);

        $request->user()->hobbies()->create([
            'hobbies_name' => $request->hobbies_name,
            'hobbies_related_work' => $request->hobbies_related_work,

        ]);

        return redirect('/home');
    }
    public function destroy($id)
    {
      $var = Hobbies::where('hobbies_id','=',$id);
      $var->delete();

      return redirect('/home');

    }
}
