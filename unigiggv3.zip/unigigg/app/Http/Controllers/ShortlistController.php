<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Model\Student\EmShortlist;
use App\Model\Student\Jobs;
use App\Model\Student\UserInfo;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use DB;

class ShortlistController extends Controller
{
    //
    public function __construct()
    {
      $this->middleware('auth');
    }

    public function store(Request $request)
    {

      $input = $request->all();

      EmShortlist::create($input);

      return redirect('/home');
    }

    public function shortlistview()
    {
      $shortlisted = DB::table('em_shortlists')
                    ->join('user_info', 'em_shortlists.user_id', '=', 'user_info.user_id')
                    ->join('jobs', 'em_shortlists.user_id', '=', 'jobs.user_id')
                    ->select('em_shortlists.*','user_info.*','jobs.job_name')
                    ->get();

    return view('employer.shortlisted', [
        'shortlisted'=>$shortlisted,

        ]);

    }
}
