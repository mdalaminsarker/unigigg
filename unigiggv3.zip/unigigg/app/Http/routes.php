<?php

/*
|--------------------------------------------------------------------------
| Routes File
|--------------------------------------------------------------------------
|
| Here is where you will register all of the routes in an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('/recruiter', function () {
    return view('rec');
});
Route::get('/talent', function () {
    return view('talent');
});


/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| This route group applies the "web" middleware group to every route
| it contains. The "web" middleware group is defined in your HTTP
| kernel and includes session state, CSRF protection, and more.
|
*/

Route::group(['middleware' => ['web']], function () {
    //
    Route::get('/employer/login','EmployerController@login');

    //Registration
    Route::get('employer/register', 'EmployerController@register');


    Route::get('/employer', 'EmployerController@index');
    Route::get('/employerinfo', 'EmployerInfoController@index');
    Route::post('/employerinfo', 'EmployerInfoController@store');

    Route::get('/postjobs', 'EmployerController@postjobs');
    Route::post('/postjobs', 'JobsController@store');
    Route::post('postjobs/{id}','JobsController@destroy');
    Route::get('/postedjobs', 'JobsController@show');

    Route::get('/jobs', 'JobsController@jobboard');
    Route::get('/chakri', 'JobsController@chakriboard');

    Route::get('/whoapplied', 'ApplyController@showApplied');
    Route::post('/shortlist','ShortlistController@store');
    Route::get('/shortlists','ShortlistController@shortlistview');
    Route::post('/shortlist/{id}','ShortlistController@destroy');
    Route::post('/finalize/{id}','ShortlistController@finalize');
    //
    //EccentricJobs
    Route::get('eccentricJobspostem','OddJobsController@empostjobs');
    Route::get('eccentricJobs','OddJobsController@index');
    Route::get('eccentricJobspost','OddJobsController@postjobs');
    Route::post('eccentricJobspost','OddJobsController@postjob');
    Route::get('eccentricJobsApplied', 'OddJobsController@whoapplied');
    Route::get('eccentricJobsAppliedem', 'OddJobsController@whoapplied');


});

Route::group(['middleware' => 'web'], function () {
    Route::auth();

    Route::get('/home', 'HomeController@index');
    Route::post('/pdf/{user_id}','CVController@createPdf');

    Route::get('/userinfo', 'UserInfoController@create');
    Route::post('/userstore', 'UserInfoController@store');
    Route::post('/userupdate/{id}', 'UserInfoController@update');
    //skills
    Route::post('/skillstore', 'SkillController@store');
    Route::post('/skill/{id}','SkillController@destroy');

    //interest
    Route::post('/intereststore', 'InterestController@store');
    Route::post('/interest/{id}','InterestController@destroy');

    Route::post('/hobbystore', 'HobbyController@store');
    Route::post('/hobby/{id}','HobbyController@destroy');

    Route::post('/edustore', 'EducationController@store');
  //  Route::get('edupdate/{id}','EducationController@updateview');
    Route::post('/edupdate/{id}','EducationController@update');
    Route::post('/edudel/{id}','EducationController@destroy');

    Route::post('/imagestore', 'ImageController@store');



    Route::post('/experiencestore', 'ExperienceController@store');
    Route::post('/experience/{id}','ExperienceController@destroy');

    Route::post('/exccstore', 'ExtraCurController@store');
    Route::post('/excc/{id}','ExtraCurController@destroy');

    Route::post('/funstore', 'FunFactsController@store');
    Route::post('/apply', 'ApplyController@store');
    Route::post('/apply/eccentric', 'OddAppliedController@store');

    //shows talent profile
    Route::get('/profile/{id}', 'ApplyController@studentemview');

    Route::get('/jobsapplied', 'StudentAppliedController@index');
    Route::get('/eccentricJobsiApplied', 'OddJobsController@oddwhereiapplied');
    Route::post('/removeapplication/{id}', 'StudentAppliedController@destroy');
});
