<?php

/*
|--------------------------------------------------------------------------
| Routes File
|--------------------------------------------------------------------------
|
| Here is where you will register all of the routes in an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

Route::get('/', function () {
    return view('welcome');
});

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| This route group applies the "web" middleware group to every route
| it contains. The "web" middleware group is defined in your HTTP
| kernel and includes session state, CSRF protection, and more.
|
*/

Route::group(['middleware' => ['web']], function () {
    //
    Route::get('/employer/login','EmployerController@login');

    //Registration
    Route::get('employer/register', 'EmployerController@register');


    Route::get('/employer', 'EmployerController@index');
    Route::get('/employerinfo', 'EmployerInfoController@index');
    Route::post('/employerinfo', 'EmployerInfoController@store');

    Route::get('/postjobs', function(){
      return view('employer.postjob');
    });
});

Route::group(['middleware' => 'web'], function () {
    Route::auth();

    Route::get('/home', 'HomeController@index');

    Route::get('/userinfo', 'UserInfoController@create');

    Route::post('/skillstore', 'SkillController@store');

    Route::post('/intereststore', 'InterestController@store');

    Route::post('/hobbystore', 'HobbyController@store');

    Route::post('/edustore', 'EducationController@store');

    Route::post('/imagestore', 'ImageController@store');

    Route::post('/userstore', 'UserInfoController@store');

    Route::post('/experiencestore', 'ExperienceController@store');

    Route::post('/exccstore', 'ExtraCurController@store');

    Route::post('/funstore', 'FunFactsController@store');
});
