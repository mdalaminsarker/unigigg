<?php

namespace App\Model\Employer;

use Illuminate\Database\Eloquent\Model;

class EmShortlist extends Model
{
    //
}
