<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Jobs extends Model
{
    //
    protected $fillable = [
      'job_name',
      'job_type',
      'job_salary',
      'job_location',
      'job_description',
      'job_reqs',
      'job_additional_reqs',
      'job_start_date',
      'job_last_date_application',
    ];
    

}
