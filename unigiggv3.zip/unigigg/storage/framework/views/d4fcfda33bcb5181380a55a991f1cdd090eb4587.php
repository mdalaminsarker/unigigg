

    <div class="panel panel-default">
      <div class="panel-heading"><a class="btn btn-primary btn-block btn-lg" data-toggle="collapse" href="#collapsefun">Someting About You</a></div>
        <div id="collapsefun" class="panel-collapse collapse">
      <div class="panel-body">

    <?php echo Form::open(array('url' => '/funstore')); ?>



    <div class="form-group">
      <?php echo Form::label('fun_facts', 'Decribe yourself in one sentence:', ['class' => 'control-label']); ?>

      <?php echo Form::text('fun_facts', null, ['class' => 'form-control']); ?>

    </div>
    <div class="form-group">
      <?php echo Form::label('inspiration_qot', 'What is you fav inspirational qoute:', ['class' => 'control-label']); ?>

      <?php echo Form::text('inspiration_qot', null, ['class' => 'form-control']); ?>

    </div>
    <div class="form-group">
      <?php echo Form::label('Why_you', 'Why People Hire You ?', ['class' => 'control-label']); ?>

      <?php echo Form::textarea('Why_you', null, ['class' => 'form-control']); ?>

    </div>
    <div class="form-group">
      <?php echo Form::label('Why_not_you', 'Why should not People Hire You ?', ['class' => 'control-label']); ?>

      <?php echo Form::textarea('Why_not_you', null, ['class' => 'form-control']); ?>

    </div>


    <?php echo Form::submit('Add', ['class' => 'btn btn-primary']); ?>


 <?php echo Form::close(); ?>


</div>
</div>
</div>
