<?php $__env->startSection('content'); ?>
  <div class="container ">
    <div class="row">
      <?php echo $__env->make('layouts.emmenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <div class="col-md-6">
        <div class="well">
          <h4 class="text-info">Build Company Profile</h4>
        </div>
        <h1 class="well well-lg">Basic info</h1>
        <div class="container">

          <div class="col-md-6">
            <?php echo Form::open(array('url' => '/employerinfo')); ?>


            <div class="form-group">
                <?php echo Form::label('company_name', 'Company Name:'); ?>

                <?php echo Form::text('company_name', null, ['class'=>'form-control']); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('company_type', 'Type:'); ?>

                <?php echo Form::text('company_type', null, ['class'=>'form-control'] ); ?>

            </div>
            <div class="form-group">
                <?php echo Form::label('company_size', 'Size:'); ?>

                <?php echo Form::text('company_size', null, ['class'=>'form-control'] ); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('company_description', 'Description:'); ?>

                <?php echo Form::textarea('company_description', null, ['class'=>'form-control', 'rows'=>2] ); ?>

            </div>


            <div class="form-group">
                <?php echo Form::submit('Save', array( 'class'=>'btn btn-success form-control' )); ?>

            </div>

            <?php echo Form::close(); ?>

            </div>


        </div>
      </div>
      </div>
      </div>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.employerapp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>