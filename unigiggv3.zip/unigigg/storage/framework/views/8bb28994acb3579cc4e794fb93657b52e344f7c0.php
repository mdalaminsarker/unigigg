<?php $__env->startSection('content'); ?>
  <div class="container ">
    <div class="row">
  
          <?php echo $__env->make('layouts.emmenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


      <div class="col-md-10">
        <div class="well">
          <h4 class="text-info">Current Jobs</h4>
        </div>
        <div class="col-md-10">
          <?php if(count($jobs)>0): ?>

              <?php foreach($jobs as $job): ?>
                <hr>
                  <div class="panel panel-primary">
                    <div class="panel-heading">
                      <h3 class="panel-title"><?php echo e($job->job_name); ?></h3>
                    </div>
                    <div class="panel-body">
                      Type: <?php echo e($job->job_type); ?>

                      <li>Location: <?php echo e($job->job_location); ?></li>
                      <li>Salary: <?php echo e($job->job_salary); ?></li>

                        <p>
                          <strong>Description: </strong><?php echo e($job->job_description); ?>

                        </p>
                        <p>
                          <strong>Requirements: </strong> <?php echo e($job->job_reqs); ?>

                        </p>
                        <p>
                        <strong>  Additional Requirements: </strong>  <?php echo e($job->job_reqs_additional); ?>

                        </p>
                        <p>
                        <strong>  Application Deadline: </strong>  <?php echo e($job->job_last_date_application); ?>

                        </p>





                  </div>
                  <div class="panel-footer">

                                          <div class="well">
                                            <strong>Posted By <?php echo e($job->company_name); ?></strong>

                                            <!-- Check if its recruter or not-->
                                          <?php if(Auth::user()->type===1): ?>
                                          <form class="form-control" action="<?php echo e(url('apply')); ?>" method="post">
                                            <?php echo csrf_field(); ?>

                                            <div class="form-group">
                                                <input type="hidden" name="applied_for_job_id" value="<?php echo e($job->job_id); ?>">
                                            </div>
                                            <div class="form-group">
                                              <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
                                            </div>


                                            <button type="submit" name="button" class="btn btn-success">Apply</button>
                                          </form>
                                        </div>
                  </div>
                  <?php endif; ?>
              </div>

        </div>
      <?php endforeach; ?>
    <?php endif; ?>
  </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>