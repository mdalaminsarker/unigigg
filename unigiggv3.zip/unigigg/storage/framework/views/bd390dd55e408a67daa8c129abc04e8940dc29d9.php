<div class="col-md-2">
  <ul class="list-group">
    <li class="list-group-item">
      <a href="<?php echo e(url('home')); ?>"><strong><i class="fa fa-dashboard"></i> Dashboard</strong></a>

    </li>
    <li class="list-group-item">
      <a href="<?php echo e(url('employerinfo')); ?>"><strong><i class="fa fa-user-secret"></i> Build Profile</strong></a>

    </li>
    <li class="list-group-item">
      <a href="<?php echo e(url('postjobs')); ?>"><strong><i class="fa fa-edit"></i> Post Job</strong></a>

    </li>
  </li>
  <li class="list-group-item">
    <a href="shortlists"><strong>Shortlisted</strong></a>

  </li>
  <li class="list-group-item">
    <a href="<?php echo e(url('postedjobs')); ?>"><strong>Posted Jobs</strong></a>
  </ul>
  <li class="list-group-item">
    <a href="<?php echo e(url('whoapplied')); ?>"><strong>Applied</strong></a>
  </ul>
</div>
