<div class="panel panel-default">
  <div class="panel-heading"><a class="btn btn-primary btn-block btn-lg" data-toggle="collapse" href="#collapseref">Add Reference</a></div>
    <div id="collapseref" class="panel-collapse collapse">
  <div class="panel-body">

<?php echo Form::open(array('url' => '/refstore')); ?>



<div class="form-group">
  <?php echo Form::label('referred_by', 'Referee Name:', ['class' => 'control-label']); ?>

  <?php echo Form::text('referred_by', null, ['class' => 'form-control']); ?>

</div>
<div class="form-group">
  <?php echo Form::label('reference_description', 'Description:', ['class' => 'control-label']); ?>

  <?php echo Form::textarea('reference_description', null, ['class' => 'form-control']); ?>

</div>
<div class="form-group">
  <?php echo Form::label('referee_number', 'Referee Contact:', ['class' => 'control-label']); ?>

  <?php echo Form::text('referee_number', null, ['class' => 'form-control']); ?>

</div>

<?php echo Form::submit('Add', ['class' => 'btn btn-primary']); ?>


<?php echo Form::close(); ?>


</div>
</div>
</div>
