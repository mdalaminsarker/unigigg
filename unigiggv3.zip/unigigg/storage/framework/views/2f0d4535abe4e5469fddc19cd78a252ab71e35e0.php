<?php if(count($images)>0): ?>
  <?php foreach($images as $image): ?>
    <img src="<?php echo '/images/'.$image->filePath; ?>" alt="propic" height="200px" width="200px" style="border-radius:50%;" />

  <?php endforeach; ?>
<?php else: ?>
  <img src="https://minions-funmobility.netdna-ssl.com/wp-content/uploads/2015/05/signup-after-img1.jpg" alt="Pro Pic" height="200px" width="200px" />


<?php endif; ?>
