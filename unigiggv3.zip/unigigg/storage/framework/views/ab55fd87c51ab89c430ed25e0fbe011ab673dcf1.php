

    <div class="panel panel-default">
      <div class="panel-heading"><a class="btn btn-primary" data-toggle="collapse" href="#collapse3">Interests</a></div>
      <div id="collapse3" class="panel-collapse collapse">
          <div class="panel-body">

    <?php echo Form::open(array('url' => '/intereststore')); ?>



    <div class="form-group">
      <?php echo Form::label('interest_name', 'Interest Name:', ['class' => 'control-label']); ?>

      <?php echo Form::text('interest_name', null, ['class' => 'form-control']); ?>

    </div>


    <?php echo Form::submit('Add', ['class' => 'btn btn-primary']); ?>


 <?php echo Form::close(); ?>


</div>
</div>

</div>
