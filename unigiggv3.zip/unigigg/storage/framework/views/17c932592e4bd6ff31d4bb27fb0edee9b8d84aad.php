<?php $__env->startSection('content'); ?>
  <div class="container ">
    <div class="row">

      <div class="col-md-8">
        <div class="well">
          <h4 class="text-info">Applied Candidates</h4>
        </div>
        <div class="jumbotron">
          <?php foreach($applied as $seek ): ?>
            <table class="table table-striped table-hover">
              <thead>
                <tr>
                  <th>
                    Job Name
                  </th>
                  <th>
                    Candidate Name
                  </th>
                  <th>
                    Candidate institute
                  </th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>
                    <?php echo e($seek->job_name); ?>

                  </td>
                  <td>
                    <?php echo e($seek->fname); ?> <?php echo e($seek->lname); ?>

                  </td>
                  <td>
                    <?php echo e($seek->institute); ?>

                  </td>
                </tr>
              </tbody>
            </table>

          <?php endforeach; ?>
        </div>
      </div>
    </div>
  </div>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>