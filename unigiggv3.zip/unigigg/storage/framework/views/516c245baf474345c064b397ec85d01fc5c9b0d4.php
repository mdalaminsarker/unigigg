<div >

  <?php foreach($extracs as $excc): ?>
  <h5>Extra Curricular Activities</h5>
  <table class="table table-striped table-hover">
    <thead>
      <tr>
        <th>
          Title
        </th>

        <th>
          Starting Date
        </th>
        <th>
          End Date
        </th>
        <th>
          Description
        </th>

        <tr>
        </thead>
        <tbody>

            <tr>
              <td>
                <?php echo e($excc->excc_name); ?>

              </td>

              <td>
                <?php echo e($excc->excc_start_date); ?>

              </td>
              <td>
                <?php echo e($excc->excc_end_date); ?>

              </td>
              <td>
                <?php echo e($excc->excc_description); ?>

              </td>
              <table>
                <form action="<?php echo e(url('excc',$excc->excc_id)); ?>" method="POST">
                  <?php echo csrf_field(); ?>

                  <button type="submit" class="btn btn-danger ">
                    <i class="fa fa-cross"></i> Delete
                  </button>
                </form>
              </table>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
