<?php $__env->startSection('content'); ?>
  <div class="container ">
    <div class="row">

      <div class="col-md-10">
        <a href="<?php echo e(url('home')); ?>">Go Back</a>
        <div class="panel panel-info" >


      <?php foreach($profile as $view ): ?>
        <div class="panel-heading">
          <h3 style="color:white;"><?php echo e($view->fname); ?>   <?php echo e($view->lname); ?></h3>

      </div>
      <div class="panel-body">
        <div class="well-info">

            <p>
              <?php echo e($view->institute); ?>

            </p>
          <p>
            <?php echo e($view->NId); ?>

          </p>
        </div>
      <?php endforeach; ?>
      <?php foreach($skill as $skills): ?>
        <div class="well">
          <?php echo e($skills->skill_name); ?>

        </div>

      <?php endforeach; ?>
      <?php foreach($education as $edu): ?>
        <div class="well">
          <?php echo e($edu->Degree_name); ?>

          <?php echo e($edu->Degree_result); ?>

        </div>

      <?php endforeach; ?>




      </div>
      <div class="panel-footer">
        <button type="button" name="button">Shortlist</button>
      </div>
    </div>

  </div>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>