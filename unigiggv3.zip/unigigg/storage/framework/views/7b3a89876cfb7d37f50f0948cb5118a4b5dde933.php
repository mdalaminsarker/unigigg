<?php $__env->startSection('content'); ?>
  <div class="container ">
    <div class="row">

      <div class="col-md-10">
        <div class="panel panel-info">


      <?php foreach($profile as $view ): ?>
        <div class="panel-heading">
          <h3 class="inverse"><?php echo e($view->fname); ?>   <?php echo e($view->lname); ?></h3>

      </div>
      <div class="panel-body">
        <div class="well-info">

            <?php echo e($view->institute); ?><br>
            <?php echo e($view->NId); ?><br>
        </div>

          <?php endforeach; ?>
          <p>
          <div class="well">
            <?php foreach($hobbies as $hobby ): ?>
              <?php echo e($hobby->hobbies_name); ?>

              <p>
                <?php echo e($hobby->hobbies_related_work); ?>

              </p>
            <?php endforeach; ?></p>
          </div>
      </div>
      <div class="panel-footer">
        <button type="button" name="button">Shortlist</button>
      </div>
    </div>
  </div>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>