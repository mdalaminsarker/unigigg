

    <div class="panel panel-default">
      <div class="panel-heading"><a data-toggle="collapse" href="#collapse6">Add Hobbies</a></div>
        <div id="collapse6" class="panel-collapse collapse">
      <div class="panel-body">

    <?php echo Form::open(array('url' => '/hobbystore')); ?>



    <div class="form-group">
      <?php echo Form::label('hobbies_name', 'Hobby Name:', ['class' => 'control-label']); ?>

      <?php echo Form::text('hobbies_name', null, ['class' => 'form-control']); ?>

    </div>
    <div class="form-group">
      <?php echo Form::label('hobbies_related_work', 'Tell Us Someting:', ['class' => 'control-label']); ?>

      <?php echo Form::textarea('hobbies_related_work', null, ['class' => 'form-control']); ?>

    </div>


    <?php echo Form::submit('Add', ['class' => 'btn btn-primary']); ?>


 <?php echo Form::close(); ?>


</div>
</div>
</div>
