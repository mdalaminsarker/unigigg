<?php $__env->startSection('content'); ?>
  <div class="container ">
    <div class="row">
      <?php echo $__env->make('layouts.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <div class="col-md-6">
        <div class="well">
          <h4 class="text-info">Build Profile</h4>
          <small>Click on buttons to add data</small>
          <?php if(count($errors)>0): ?>
            <div class="alert alert-danger">
              <?php foreach($errors->all() as $error): ?>
                <p><?php echo e($error); ?></p>
              <?php endforeach; ?>
            </div>
          <?php endif; ?>
          <?php if(notify()->ready()): ?>
            <div class="alert alert-<?php echo e(notify()->type()); ?>">
              <?php echo e(notify()->message()); ?>

            </div>
          <?php endif; ?>


        </div>

        <div class="panel panel-default">
          <div class="panel-heading"><a class="btn btn-primary btn-lg btn-block" data-toggle="collapse" href="#collapse2">Basic Information</a></div>
          <div id="collapse2" class="panel-collapse collapse">
            <div class="panel-body">
              <?php echo Form::open(array('url' => '/userstore')); ?>

              <div class="md-col-6">



                <div class="form-group">
                  <?php echo Form::label('fname', 'First Name', ['class' => 'control-label']); ?>

                  <?php echo Form::text('fname', null, ['class' => 'form-control']); ?>

                </div>
                <div class="form-group">
                  <?php echo Form::label('lname', 'Last Name', ['class' => 'control-label']); ?>

                  <?php echo Form::text('lname', null, ['class' => 'form-control']); ?>

                </div>
                <div class="form-group">
                  <?php echo Form::label('area', 'Address', ['class' => 'control-label']); ?>

                  <?php echo Form::text('lname', null, ['class' => 'form-control']); ?>

                  <span><small>Provide your living area in Dhaka</small></span>
                </div>
                <div class="form-group">
                  <?php echo Form::label('post_code', 'post_code', ['class' => 'control-label']); ?>

                  <?php echo Form::text('post_code', null, ['class' => 'form-control']); ?>

                </div>
                <div class="form-group">
                  <?php echo Form::label('other', 'Other Details (if any)', ['class' => 'control-label']); ?>

                  <?php echo Form::text('other', null, ['class' => 'form-control']); ?>

                </div>
                <div class="form-group">
                  <?php echo Form::label('institute', 'Institute :', ['class' => 'control-label']); ?>

                  <?php echo Form::text('institute', null, ['class' => 'form-control']); ?>

                </div>
                <div class="form-group">
                  <?php echo Form::label('passing_date', 'Passing Year :', ['class' => 'control-label']); ?>

                  <?php echo Form::date('passing_date', null, ['class' => 'form-control']); ?>

                </div>
                <div class="form-group">
                  <?php echo Form::label('mobile', 'Contact No :', ['class' => 'control-label']); ?>

                  <?php echo Form::text('mobile', null, ['class' => 'form-control']); ?>

                </div>
                <div class="form-group">
                  <?php echo Form::label('universityId', 'University ID:', ['class' => 'control-label']); ?>

                  <?php echo Form::text('universityId', null, ['class' => 'form-control']); ?>

                </div>
                <div class="form-group">
                  <?php echo Form::label('NId', 'NID:', ['class' => 'control-label']); ?>

                  <?php echo Form::text('NId', null, ['class' => 'form-control']); ?>

                </div>
                <div class="form-group">
                  <?php echo Form::label('facebookId', 'Facebook ID:', ['class' => 'control-label']); ?>

                  <?php echo Form::text('facebookId', null, ['class' => 'form-control']); ?>

                </div>
                <div class="form-group">
                  <?php echo Form::label('LinkedInId', 'LinkedIn ID:', ['class' => 'control-label']); ?>

                  <?php echo Form::text('LinkedInId', null, ['class' => 'form-control']); ?>

                </div>
                <div class="form-group">
                  <?php echo Form::label('youtube', 'Video Profile', ['class' => 'control-label']); ?>

                  <?php echo Form::text('youtube', null, ['class' => 'form-control']); ?>

                </div>



                <?php echo Form::submit('Add', ['class' => 'btn btn-primary']); ?>


                <?php echo Form::close(); ?>


              </div>



            </div>
          </div>
          <br>


          <?php echo $__env->make('student.skills', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <?php echo $__env->make('student.interest', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <?php echo $__env->make('student.hobby', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <?php echo $__env->make('student.education', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <?php echo $__env->make('student.image', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <?php echo $__env->make('student.experience', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <?php echo $__env->make('student.excc', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <?php echo $__env->make('student.funfacts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <?php echo $__env->make('student.ref', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>



        </div>
      </div>
    </div>
  </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>