<!DOCTYPE html>
<html lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>

  <title>CV</title>
  <style>
  #header {
    background-color:black;
    color:white;
    text-ah5gn:center;
    padding:5px;
  }
  #nav {
    h5ne-height:30px;
    background-color:#eeeeee;
    height:300px;
    width:100px;
    float:left;
    padding:5px;
  }
  #section {
    width:350px;
    float:left;
    padding:10px;
  }
  #footer {
    background-color:black;
    color:white;
    clear:both;
    text-ah5gn:center;
    padding:5px;
  }
  td {
  width:180px;
  font:12pt arial;}

td.leftAlign {text-align:left;}
td.rightAlign {text-align:right;}
td.center {text-align:center;}
td.justify {text-align:justify;}
  </style>


</head>
<body >

  <main  >
    <div id="details">
      <div id="invoice">
        <?php foreach($data as $user): ?>
          <h2><?php echo e($user->fname); ?> <?php echo e($user->lname); ?></h2>
        <?php echo e($user->mobile); ?><br>
          <?php echo e($user->area); ?><br>
        <?php endforeach; ?>
        <hr>

      </div>
    </div>
  </main>





      <h3>Education</h3>
      <div   >
        <?php foreach($education as $edu ): ?>
          <table  >
          <tr>
            <th>
              Degree
            </th>
            <th>
              Institute
            </th>
            <th>
              Passing Year
            </th>
            <th>
              Result
            </th>
            </tr>
            <tr>

                <td class="center">
                  <?php echo e($edu->Degree_name); ?>

                </td>


          <td class="center">
              <?php echo e($edu->Degree_institute); ?>

          </td>
          <td class="center">
            <?php echo e($edu->Degree_end_date); ?>

          </td>
          <td class="center">
            <?php echo e($edu->Degree_result); ?> 
          </td>
            </tr>

          </table>



        <?php endforeach; ?>


    </div>
    <hr>
    <h3>Skills</h3>
    <div style="float:right;">
      <?php foreach($skill as $skills ): ?>
        <?php echo e($skills->skill_name); ?>,

      <?php endforeach; ?>
    </div>
    <hr>
    <?php if(count($exps)>0): ?>
    <h3>Experiences</h3>
    <div >
        <?php foreach($exps as $exp ): ?>
    <p>
      <strong>Title:</strong> <?php echo e($exp->exp_name); ?><br>
      <strong>Description</strong>:<br>
        <?php echo e($exp->exp_description); ?><br>
      <small><strong>start date :</strong></small> <?php echo e($exp->exp_start_date); ?> <small><strong>end date :</strong></small> <?php echo e($exp->exp_end_date); ?>

    </p>
    <?php endforeach; ?>

    </div>
      <?php endif; ?>
      <hr>
      <?php if(count($refs)>0): ?>
      <h3>References</h3>
      <div >
        <?php foreach($refs as $ref ): ?>
    <p>
      <strong>Referred By</strong> <?php echo e($ref->referred_by); ?><br>
      <strong>Description</strong>:<br>
        <?php echo e($ref->reference_description); ?><br>
      <small><strong>Contact : </strong><?php echo e($ref->referee_number); ?></small>  </p>
    <?php endforeach; ?>
  <?php endif; ?>
      </div>
      <hr>
      <?php if(count($extras)>0): ?>
      <h3>References</h3>
      <div >
        <?php foreach($extras as $excc ): ?>
    <p>
      <strong>Referred By</strong> <?php echo e($excc->excc_name); ?><br>
      <strong>Description</strong>:<br>
        <?php echo e($excc->excc_description); ?><br>
        <small><strong>start date :</strong></small> <?php echo e($excc->excc_start_date); ?> <small><strong>end date :</strong></small> <?php echo e($excc->exp_end_date); ?>

      <?php endforeach; ?>
  <?php endif; ?>
      </div>



  </body>
  </html>
