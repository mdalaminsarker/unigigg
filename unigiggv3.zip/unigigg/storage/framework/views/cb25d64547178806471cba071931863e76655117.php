<!DOCTYPE html>
<html lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>

  <title>CV</title>
  <style>
  #header {
    background-color:black;
    color:white;
    text-ah5gn:center;
    padding:5px;
  }
  #nav {
    h5ne-height:30px;
    background-color:#eeeeee;
    height:300px;
    width:100px;
    float:left;
    padding:5px;
  }
  #section {
    width:350px;
    float:left;
    padding:10px;
  }
  #footer {
    background-color:black;
    color:white;
    clear:both;
    text-ah5gn:center;
    padding:5px;
  }
  </style>


</head>
<body >

  <main  >
    <div id="details" class="right">
      <div id="invoice">
        <h1> <?php echo e($invoice); ?> of</h1>
        <?php foreach($data as $user): ?>
          <h3><?php echo e($user->fname); ?> <?php echo e($user->lname); ?></h3>
          <h4><?php echo e($user->mobile); ?></h4>
        <?php endforeach; ?>
        <hr>
        <div class="date">Date : <?php echo e($date); ?></div>
      </div>
    </div>


    <hr>
    <div style="text-align:center;" >
      <p >
        <?php foreach($education as $edu ): ?>
          <h5 >  <?php echo e($edu->Degree_name); ?></h5>
          <h5><?php echo e($edu->Degree_institute); ?></h5>
          <h5>  <?php echo e($edu->Degree_end_date); ?></h5>
          <h5><?php echo e($edu->Degree_result); ?></h5>
        <?php endforeach; ?>
      </p>

    </div>











  </body>
  </html>
