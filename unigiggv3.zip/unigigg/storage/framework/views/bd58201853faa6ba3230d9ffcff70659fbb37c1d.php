<?php $__env->startSection('content'); ?>
  <div class="container">
    <div class="row">
      <a href="<?php echo e(url('home')); ?>"><h4 class="text-primary"><i class="fa fa-arrow-left"></i> Go Back </h4></a>
      <?php if(count($oddjobs)>0): ?>

        <?php foreach($oddjobs as $jobs): ?>
          <div class="panel panel-default">
            <div class="panel-heading">
              <?php echo e($jobs->title); ?>

            </div>
            <div class="panel-body">
              <h5><?php echo e($jobs->type); ?></h5>
              <p>
                <?php echo e($jobs->description); ?>

              </p>
              <h5><?php echo e($jobs->offering); ?></h5>

            </div>
            <div class="panel-footer">
              <button type="submit" name="button" class="btn btn-success">Apply</button>
            </div>

          </div>
        <?php endforeach; ?>

      <?php endif; ?>


    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>