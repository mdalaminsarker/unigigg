<?php $__env->startSection('content'); ?>
  <div class="container">
    <div class="row">
      <a href="<?php echo e(url('home')); ?>"><h4 class="text-primary"><i class="fa fa-arrow-left"></i> Go Back </h4></a>
      <?php if(count($oddjobs)>0): ?>

        <?php foreach($oddjobs as $jobs): ?>
          <div class="panel panel-default">
            <div class="panel-heading">
              <h3><?php echo e($jobs->title); ?></h3>
            </div>
            <div class="panel-body">
              <h5><?php echo e($jobs->type); ?></h5>
              <p>
                <?php echo e($jobs->description); ?>

              </p>
              <h5><?php echo e($jobs->offering); ?></h5>

            </div>
            <div class="panel-footer">
              <?php if(Auth::user()->id!=$jobs->user_id): ?>
                <form class="form-control" action="<?php echo e(url('apply/eccentric')); ?>" method="post">
                  <?php echo csrf_field(); ?>

                  <div class="form-group">
                      <input type="hidden" name="applied_for_odd_id" value="<?php echo e($jobs->odd_id); ?>">
                  </div>
                  <div class="form-group">
                    <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
                  </div>


                  <button type="submit" name="button" class="btn btn-success">Apply</button>

                </form>
            <?php endif; ?>
            <?php if($jobs->user_id===Auth::user()->id): ?>
              You posted this job
            <?php else: ?>
              <hr>
              Posted By  <?php echo e($jobs->user_id); ?>

            <?php endif; ?>


            </div>

          </div>
        <?php endforeach; ?>

      <?php endif; ?>


    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>