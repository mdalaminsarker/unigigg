<?php $__env->startSection('content'); ?>
  <div class="container ">
    <div class="row">
      <?php echo $__env->make('layouts.emmenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <div class="col-md-6">
        <div class="well">
          <h4 class="text-info">Post a Job</h4>
        </div>

        <div class="container">

          <div class="col-md-6">
            <?php echo Form::open(array('url' => '/employerinfo', 'file'=>true)); ?>


            <div class="form-group">
                <?php echo Form::label('job_name', 'Tltle:'); ?>

                <?php echo Form::text('job_name', null, ['class'=>'form-control']); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('job_type', 'Job Type:'); ?>

                <?php echo Form::text('job_type', null, ['class'=>'form-control'] ); ?>

            </div>
            <div class="form-group">
                <?php echo Form::label('job_salary', 'Salary:'); ?>

                <?php echo Form::text('job_salary', null, ['class'=>'form-control'] ); ?>

            </div>
            <div class="form-group">
                <?php echo Form::label('job_location', 'Location:'); ?>

                <?php echo Form::text('job_location', null, ['class'=>'form-control'] ); ?>

            </div>


            <div class="form-group">
                <?php echo Form::label('job_description', 'Job Description:'); ?>

                <?php echo Form::textarea('job_description', null, ['class'=>'form-control', 'rows'=>4] ); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('job_reqs', 'Job Requirments:'); ?>

                <?php echo Form::textarea('job_reqs', null, ['class'=>'form-control', 'rows'=>2] ); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('job_additional_reqs', 'Additional Requirments:'); ?>

                <?php echo Form::textarea('job_additional_reqs', null, ['class'=>'form-control', 'rows'=>2] ); ?>

            </div>
            <div class="form-group">
                <?php echo Form::label('job_start_date', 'Commencing Date:'); ?>

                <?php echo Form::date('job_start_date', null, ['class'=>'form-control'] ); ?>

            </div>
            <div class="form-group">
                <?php echo Form::label('job_last_date_application', 'Last Date Of Application'); ?>

                <?php echo Form::date('job_last_date_application', null, ['class'=>'form-control'] ); ?>

            </div>



            <div class="form-group">
                <?php echo Form::submit('Post Job', array( 'class'=>'btn btn-success form-control' )); ?>

            </div>

            <?php echo Form::close(); ?>

            </div>


        </div>
      </div>
      </div>
      </div>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.employerapp', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>