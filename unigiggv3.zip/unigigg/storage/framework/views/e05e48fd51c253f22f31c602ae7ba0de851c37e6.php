<?php $__env->startSection('content'); ?>
  <div class="container">
      <div class="row">
        <div style="text-align:center">


        <h1>Recruitment, Made Easy</h1>
        <img src="http://media.gallup.com/GMJ/art/20051110_2_2.gif" alt="" />
      </div>
    </div>
  m1</div>
  <?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>