<?php $__env->startSection('content'); ?>
  <div class="container ">
    <div class="row">
    <?php echo $__env->make('layouts.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <div class="col-md-10">
        <div class="well">
          <h4 class="text-info">Applied Candidates</h4>
        </div>

        <?php foreach( $applied as $seek ): ?>
          <?php if($seek->user_id===Auth::user()->id): ?>
          <div class="panel panel-default">
            <div class="panel-heading">

              <h4><?php echo e($seek->fname); ?> <?php echo e($seek->lname); ?></h4>

            </div>
            <div class="panel-body">
              <p class="col-md-4">
                <iframe width="250" height="150" src="https://www.youtube.com/embed/<?php echo e($seek->youtube); ?>" frameborder="0" allowfullscreen></iframe>

              </p>

              <p class="col-md-4">
                <strong >Applied for</strong> : <?php echo e($seek->title); ?>

                <strong>Institute</strong>: <?php echo e($seek->institute); ?>

              </p>


            </div>

            <div class="panel-footer">


              <p class="inline">


              <form action="<?php echo e(url('/profile',$seek->id)); ?>" method="GET">
                <?php echo csrf_field(); ?>

                <button type="submit" class="btn btn-info btn-sm btn-block-sm">
                  <i class="fa fa-user"></i> view profile
                </button>
              </form>
<!--
              <form action="<?php echo e(url('shortlist')); ?>" method="post">
                <?php echo csrf_field(); ?>

                <input type="hidden" name="user_id" value="<?php echo e($seek->id); ?>">
                <input type="hidden" name="shortlisted_for_job_id" value="<?php echo e($seek->odd_id); ?>">
                <button type="submit" class="btn btn-warning btn-sm btn-block-sm">
                  <i class="fa fa-user"></i> Shortlist
                </button>
              </form>
            -->
              </p>


            </div>

          </div>
              <?php endif; ?>

        <?php endforeach; ?>


      </div>
    </div>
  </div>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>