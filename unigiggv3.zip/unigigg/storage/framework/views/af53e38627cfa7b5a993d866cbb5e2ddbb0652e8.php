<div >


  <p>
    <?php if(count($infos)>0): ?>

      <?php foreach($infos as $users): ?>
        <p>

            <iframe width="400" height="250" src="https://www.youtube.com/embed/<?php echo e($users->youtube); ?>

            " frameborder="0" allowfullscreen></iframe>'
            <hr>
          

          <hr>
          <h6>Phone : <?php echo e($users->mobile); ?></h6>
          <h6>Institute: <?php echo e($users->institute); ?></h6>
          <h6>NID : <?php echo e($users->NId); ?></h6>
        </p>
        <p>
        <h5>University ID :<?php echo e($users->universityId); ?></h5>
        Facebook: Id:
        <a href="<?php echo e($users->facebookId); ?>" target="_blank"><?php echo e($users->fname); ?></a><br>
          <button type="submit" class="btn btn-primary" data-toggle="modal" data-target="#myModaluserinfo" ><i class="fa fa-edit"></i> Edit</button>
          <hr>
          <form action="<?php echo e(url('pdf',$users->user_id)); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <button type="submit" class="btn btn-info">
              <i class="fa fa-tasks"></i> Generate CV
            </button>
          </form>
          <hr>
      <?php endforeach; ?>

  <?php endif; ?>



  </p>
  <!-- Modal -->
  <div class="modal fade" id="myModaluserinfo" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
          <h4 class="modal-title" id="myModalLabel">Update Information</h4>
        </div>
        <div class="modal-body">
          <?php echo $__env->make('student.partials.update.userinfoupdate', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>

        </div>
      </div>
    </div>
  </div>
  <!-- Modal ends -->
</div>
