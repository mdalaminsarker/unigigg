<div class="container">
  <div class="row">
    <?php echo $__env->make('layouts.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="col-md-10 ">
      <div class="panel panel-primary">
        <div class="panel-heading">Dashboard</div>

        <div class="panel-body">
          <h4>Welcome <?php echo e(Auth::user()->name); ?> !! </h4>
          <img src="https://minions-funmobility.netdna-ssl.com/wp-content/uploads/2015/05/signup-after-img1.jpg" alt="Pro Pic" height="200px" width="200px"/>


          <div class="jumbotron">
            <p class="text-primary">

            </p>

            <p>
              <?php if(count($infos)>0): ?>
                <?php foreach($infos as $users): ?>
                  <p>
                    <h6>Phone : <?php echo e($users->mobile); ?></h6>
                    <h6>Address : <?php echo e($users->institute); ?></h6>
                    <h6>NID : <?php echo e($users->NId); ?></h6>
                  </p>
                  <h5>University ID :<?php echo e($users->universityId); ?></h5>
                  Facebook: Id:
                  <a href="<?php echo e($users->facebookId); ?>" target="_blank"><?php echo e($users->fname); ?></a>
                <?php endforeach; ?>
              <?php endif; ?>


            </p>
          </div>
          <!-- Skills-->
          <?php if(count($skill)>0): ?>
            <div class="jumbotron">


              <h4>Your Skills</h4>

              <?php foreach($skill as $skills): ?>
                <p>
                  <ul>
                    <li><?php echo e($skills->skill_name); ?>---><?php echo e($skills->skill_level); ?></li>
                  </ul>
                </p>

              <?php endforeach; ?>

          </div>
            <?php endif; ?>


          <!-- interest-->
            <?php if(count($interest)>0): ?>
          <div class="jumbotron">


            <h4>Your interest</h4>

              <?php foreach($interest as $interests): ?>
                <p>
                  <ul>
                    <li><?php echo e($interests->interest_name); ?></li>
                  </ul>
                </p>

              <?php endforeach; ?>

          </div>
            <?php endif; ?>

          <?php if(count($hobbies)>0): ?>
          <!-- Hobbies-->
          <div class="jumbotron">


            <h4>Your Hobbies</h4>

              <?php foreach($hobbies as $hobby): ?>
                <p>
                  <ul>
                    <li><?php echo e($hobby->hobbies_name); ?> --> <?php echo e($hobby->hobbies_related_work); ?></li>
                  </ul>
                </p>

              <?php endforeach; ?>

          </div>
          <?php endif; ?>

          <?php if(count($education)>0): ?>
            <div class="jumbotron">


              <h5>Education</h5>


              <table class="table table-striped table-hover">
                <thead class="text-primary">
                  <tr>
                    <th>
                      Degree Name
                    </th>
                    <th>
                      Degree Type
                    </th>
                    <th>
                      Starting Date
                    </th>
                    <th>
                      Passing Date
                    </th>
                    <th>
                      Institute
                    </th>
                    <th>
                      Result
                    </th>
                    <tr>
                    </thead>
                  </tbody>
                  <?php foreach($education as $edu): ?>
                    <tr>
                      <td>
                        <?php echo e($edu->Degree_name); ?>

                      </td>
                      <td>
                        <?php echo e($edu->Degree_type); ?>

                      </td>
                      <td>
                        <?php echo e($edu->Degree_start_date); ?>

                      </td>
                      <td>
                        <?php echo e($edu->Degree_end_date); ?>

                      </td>
                      <td>
                        <?php echo e($edu->Degree_institute); ?>

                      </td>
                      <td>
                        <?php echo e($edu->Degree_result); ?>

                      </td>
                    </tr>
                  </tbody>
                </table>

              <?php endforeach; ?>
            </div>
          <?php endif; ?>
          <?php if(count($experiences)>0): ?>
            <div class="jumbotron">


              <h5>Experience</h5>
              <table class="table table-striped table-hover">
                <thead>
                  <tr>
                    <th>
                      Title
                    </th>

                    <th>
                      Starting Date
                    </th>
                    <th>
                      End Date
                    </th>
                    <th>
                      Description
                    </th>

                    <tr>
                    </thead>
                    <tbody>
                      <?php foreach($experiences as $experience): ?>
                        <tr>
                          <td>
                            <?php echo e($experience->exp_name); ?>

                          </td>

                          <td>
                            <?php echo e($experience->exp_start_date); ?>

                          </td>
                          <td>
                            <?php echo e($experience->exp_end_date); ?>

                          </td>
                          <td>
                            <?php echo e($experience->exp_description); ?>

                          </td>
                        <?php endforeach; ?>
                      </tbody>
                    </table>

                  </div>
                <?php endif; ?>

                <?php if(count($extracs)>0): ?>
                  <div class="jumbotron">


                    <h5>Extra Curricular Activities</h5>
                    <table class="table table-striped table-hover">
                      <thead>
                        <tr>
                          <th>
                            Title
                          </th>

                          <th>
                            Starting Date
                          </th>
                          <th>
                            End Date
                          </th>
                          <th>
                            Description
                          </th>

                          <tr>
                          </thead>
                          <tbody>
                            <?php foreach($extracs as $excc): ?>
                              <tr>
                                <td>
                                  <?php echo e($excc->excc_name); ?>

                                </td>

                                <td>
                                  <?php echo e($excc->excc_start_date); ?>

                                </td>
                                <td>
                                  <?php echo e($excc->excc_end_date); ?>

                                </td>
                                <td>
                                  <?php echo e($excc->excc_description); ?>

                                </td>
                              <?php endforeach; ?>
                            </tbody>
                          </table>
                        </div>
                      <?php endif; ?>
                      <?php if(count($funs)>0): ?>
                        <div class="jumbotron">


                          <!--about your self -->

                          <h3>About You</h3>
                          <?php foreach($funs as $fun): ?>
                            <p>
                              <?php echo e($fun->fun_facts); ?>

                            </p>
                            <p>
                              <?php echo e($fun->inspiration_qot); ?>

                            </p>
                            <p>
                              <?php echo e($fun->Why_you); ?>

                            </p>

                          <?php endforeach; ?>
                        </div>
                      <?php endif; ?>

                      <!--about your self ends-->

                    </div>

                  </div>
                </div>





              </div>
            </div>
