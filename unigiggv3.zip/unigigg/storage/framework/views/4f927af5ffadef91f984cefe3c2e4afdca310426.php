<div class="container">
  <div class="row">
    <?php echo $__env->make('layouts.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="col-md-10 ">
      <div class="panel panel-primary">
        <div class="panel-heading">Dashboard</div>

        <div class="panel-body">
          <h4 class="well">Welcome onboard <strong><?php echo e(Auth::user()->name); ?></strong>   </h4>
          <div class="col-md-5">


          <?php if(count($images)>0): ?>
            <?php foreach($images as $image): ?>
              <img src="<?php echo '/images/'.$image->filePath; ?>" alt="propic" height="200px" width="200px" style="border-radius:30%;" />

            <?php endforeach; ?>
          <?php else: ?>
            <img src="https://minions-funmobility.netdna-ssl.com/wp-content/uploads/2015/05/signup-after-img1.jpg" alt="Pro Pic" height="200px" width="200px"/>

          <?php endif; ?>
            </div>



          <div >


            <p>
              <?php if(count($infos)>0): ?>
                <?php foreach($infos as $users): ?>
                  <p>
                    <h6>Phone : <?php echo e($users->mobile); ?><i class="fa fa-check"></i></h6>
                    <h6>Institute: <?php echo e($users->institute); ?></h6>
                    <h6>NID : <?php echo e($users->NId); ?></h6>
                  </p>
                  <h5>University ID :<?php echo e($users->universityId); ?> <i class="fa fa-check"></i></h5>
                  Facebook: Id:
                  <a href="<?php echo e($users->facebookId); ?>" target="_blank"><?php echo e($users->fname); ?></a> <i class="fa fa-check"></i>
                <?php endforeach; ?>
              <?php endif; ?>


            </p>
          </div>
          <!-- Skills-->
          <?php if(count($skill)>0): ?>
            <div class="jumbotron">


              <h4>Your Skills</h4>

              <?php foreach($skill as $skills): ?>
                <p>
                  <table class="table table-striped">
                    <thead>
                      <th>
                        Skill
                      </th>
                      <th>
                        Level
                      </th>
                      <th>
                        Experience
                      </th>
                    </thead>
                    <tbody>
                      <tr>
                        <td>
                          <?php echo e($skills->skill_name); ?>


                        </td>
                        <td>
                          <?php echo e($skills->skill_level); ?>


                        </td>
                        <td>
                          <?php echo e($skills->skill_experience); ?> Years
                        </td>
                        <td>
                          <form action="<?php echo e(url('skill',$skills->skill_id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>

                            <button type="submit" class="btn btn-danger">
                              <i class="fa fa-cross"></i> Delete
                            </button>
                          </form>

                        </td>
                      </tr>
                    </tbody>
                  </table>
                </p>

              <?php endforeach; ?>

          </div>
            <?php endif; ?>


          <!-- interest-->
            <?php if(count($interest)>0): ?>
          <div class="jumbotron">


            <h4>Your interest</h4>

              <?php foreach($interest as $interests): ?>
                <table class="table table-striped">
                  <thead>
                    <th>
                      Interests
                    </th>
                    <th>
                      Remove
                    </th>
                  </thead>
                  <tbody>
                    <tr>
                      <td>
                        <?php echo e($interests->interest_name); ?>

                      </td>
                      <td>
                         <form action="<?php echo e(url('interest',$interests->interest_id)); ?>" method="POST">
                          <?php echo csrf_field(); ?>

                          <button type="submit" class="btn btn-danger ">
                            <i class="fa fa-cross"></i> Delete
                          </button>
                        </form>

                      </td>
                    </tr>
                  </tbody>
                </table>


              <?php endforeach; ?>

          </div>
            <?php endif; ?>

          <?php if(count($hobbies)>0): ?>
          <!-- Hobbies-->
          <div class="jumbotron">


            <h4>Your Hobbies</h4>

              <?php foreach($hobbies as $hobby): ?>
                <p>
                  <table class="table table-striped">
                    <thead>
                      <th>
                        Hobby
                      </th>
                      <th>
                        Things you have done regarding your hobby
                      </th>
                    </thead>
                    <tbody>
                      <tr>
                        <td>
                          <?php echo e($hobby->hobbies_name); ?>

                        </td>
                        <td>
                          <?php echo e($hobby->hobbies_related_work); ?>

                        </td>
                        <td>
                          <form action="<?php echo e(url('hobby',$hobby->hobbies_id)); ?>" method="POST">
                           <?php echo csrf_field(); ?>

                           <button type="submit" class="btn btn-danger ">
                             <i class="fa fa-cross"></i> Delete
                           </button>
                         </form>

                        </td>
                      </tr>
                    </tbody>
                  </table>
                </p>

              <?php endforeach; ?>

          </div>
          <?php endif; ?>

          <?php if(count($education)>0): ?>
            <div class="">
              <hr>
              <br>
              <br>

              <h5>Education</h5>


              <table class="table table-striped table-hover">
                <thead class="text-primary">
                  <tr>
                    <th>
                      Degree Name
                    </th>
                    <th>
                      Degree Type
                    </th>
                    <th>
                      Starting Date
                    </th>
                    <th>
                      Passing Date
                    </th>
                    <th>
                      Institute
                    </th>
                    <th>
                      Result
                    </th>
                    <tr>
                    </thead>
                  </tbody>
                  <?php foreach($education as $edu): ?>
                    <tr>
                      <td>
                        <?php echo e($edu->Degree_name); ?>

                      </td>
                      <td>
                        <?php echo e($edu->Degree_type); ?>

                      </td>
                      <td>
                        <?php echo e($edu->Degree_start_date); ?>

                      </td>
                      <td>
                        <?php echo e($edu->Degree_end_date); ?>

                      </td>
                      <td>
                        <?php echo e($edu->Degree_institute); ?>

                      </td>
                      <td>
                        <?php echo e($edu->Degree_result); ?>

                      </td>
                      <td>
                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">
                            Edit
                        </button>

                      </td>
                      <td>
                        <form action="<?php echo e(url('edudel',$edu->education_id)); ?>" method="POST">
                          <?php echo csrf_field(); ?>

                          <button type="submit" class="btn btn-danger">
                            <i class="fa fa-cross"></i> Delete
                          </button>
                        </form>
                      </td>
                    </tr>
                  </tbody>
                </table>
                <!-- Modal -->
                  <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                    <div class="modal-dialog" role="document">
                      <div class="modal-content">
                        <div class="modal-header">
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                          <h4 class="modal-title" id="myModalLabel">Update Information</h4>
                        </div>
                        <div class="modal-body">
                          <?php echo $__env->make('student.partials.eduview', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        </div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>

                        </div>
                      </div>
                    </div>
                  </div>
                  <!-- Modal ends -->

              <?php endforeach; ?>
            </div>
          <?php endif; ?>
          <?php if(count($experiences)>0): ?>
            <div class="jumbotron">


              <h5>Experience</h5>
              <table class="table table-striped table-hover">
                <thead>
                  <tr>
                    <th>
                      Title
                    </th>

                    <th>
                      Starting Date
                    </th>
                    <th>
                      End Date
                    </th>
                    <th>
                      Description
                    </th>

                    <tr>
                    </thead>
                    <tbody>
                      <?php foreach($experiences as $experience): ?>
                        <tr>
                          <td>
                            <?php echo e($experience->exp_name); ?>

                          </td>

                          <td>
                            <?php echo e($experience->exp_start_date); ?>

                          </td>
                          <td>
                            <?php echo e($experience->exp_end_date); ?>

                          </td>
                          <td>
                            <?php echo e($experience->exp_description); ?>

                          </td>
                          <td>
                            <form action="<?php echo e(url('experience',$experience->experience_id)); ?>" method="POST">
                             <?php echo csrf_field(); ?>

                             <button type="submit" class="btn btn-danger ">
                               <i class="fa fa-cross"></i> Delete
                             </button>
                           </form>
                          </td>
                        <?php endforeach; ?>
                      </tbody>
                    </table>

                  </div>
                <?php endif; ?>

                <?php if(count($extracs)>0): ?>
                  <div class="jumbotron">


                    <h5>Extra Curricular Activities</h5>
                    <table class="table table-striped table-hover">
                      <thead>
                        <tr>
                          <th>
                            Title
                          </th>

                          <th>
                            Starting Date
                          </th>
                          <th>
                            End Date
                          </th>
                          <th>
                            Description
                          </th>

                          <tr>
                          </thead>
                          <tbody>
                            <?php foreach($extracs as $excc): ?>
                              <tr>
                                <td>
                                  <?php echo e($excc->excc_name); ?>

                                </td>

                                <td>
                                  <?php echo e($excc->excc_start_date); ?>

                                </td>
                                <td>
                                  <?php echo e($excc->excc_end_date); ?>

                                </td>
                                <td>
                                  <?php echo e($excc->excc_description); ?>

                                </td>
                                <table>
                                  <form action="<?php echo e(url('excc',$excc->excc_id)); ?>" method="POST">
                                   <?php echo csrf_field(); ?>

                                   <button type="submit" class="btn btn-danger ">
                                     <i class="fa fa-cross"></i> Delete
                                   </button>
                                 </form>
                                </table>
                              <?php endforeach; ?>
                            </tbody>
                          </table>
                        </div>
                      <?php endif; ?>
                      <?php if(count($funs)>0): ?>
                        <div class="jumbotron">


                          <!--about your self -->

                          <h3>About You</h3>
                          <?php foreach($funs as $fun): ?>
                            <p>
                              <?php echo e($fun->fun_facts); ?>

                            </p>
                            <p>
                              <?php echo e($fun->inspiration_qot); ?>

                            </p>
                            <p>
                              <?php echo e($fun->Why_you); ?>

                            </p>

                          <?php endforeach; ?>
                        </div>
                      <?php endif; ?>

                      <!--about your self ends-->

                    </div>

                  </div>
                </div>





              </div>
            </div>
