<div class="container">
  <div class="row">
    <?php echo $__env->make('layouts.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="col-md-10 ">
      <div class="panel panel-primary">
        <div class="panel-heading">Dashboard</div>

        <div class="panel-body">
          <h4 class="well">Welcome onboard <strong><?php echo e(Auth::user()->name); ?></strong>   </h4>
          <div class="col-md-5">

            <?php echo $__env->make('student.partials.userview.imageview', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

          </div>

          <br>

          <?php echo $__env->make('student.partials.userview.infoview', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <br>
          <?php if(count($education)>0): ?>
          <?php echo $__env->make('student.partials.userview.eduview', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php endif; ?>
        
          <h3>Show Data</h3>

          <ul class="nav nav-tabs">
            <li class="active"><a href="#skill" data-toggle="tab" aria-expanded="true">Skill</a></li>

            <li class=""><a href="#experience" data-toggle="tab" aria-expanded="false">Experience</a></li>
            <li class=""><a href="#interest" data-toggle="tab" aria-expanded="false">Interest</a></li>
            <li class=""><a href="#extra" data-toggle="tab" aria-expanded="false">Extra Curricular</a></li>
            <li class=""><a href="#hobby" data-toggle="tab" aria-expanded="false">Hobbies</a></li>
            <li class=""><a href="#funview" data-toggle="tab" aria-expanded="false">About</a></li>
          </ul>
          <div style="height:800px;" id="myTabContent" class="tab-content" >
            <div class="tab-pane fade active in" id="skill">

              <?php echo $__env->make('student.partials.userview.skillview', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            </div>

            <div class="tab-pane fade" id="experience">
                <?php if(count($experiences)>0): ?>
                <?php echo $__env->make('student.partials.userview.expview', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
              <?php endif; ?>
            </div>
            <div class="tab-pane fade" id="interest">
                  <?php echo $__env->make('student.partials.userview.interestview', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
            <div class="tab-pane fade" id="extra">
                  <?php echo $__env->make('student.partials.userview.exccview', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
            <div class="tab-pane fade" id="hobby">
                  <?php echo $__env->make('student.partials.userview.hobbyview', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
            <div class="tab-pane fade" id="funview">
                  <?php echo $__env->make('student.partials.userview.funview', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
          </div>

        </div>

      </div>
    </div>





  </div>
</div>
