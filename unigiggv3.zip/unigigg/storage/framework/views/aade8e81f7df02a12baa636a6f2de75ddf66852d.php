<div class="col-md-2">
  <ul class="list-group">
    <li class="list-group-item">
      <a href="<?php echo e(url('home')); ?>"><strong>Dashboard</strong></a>

    </li>
    <li class="list-group-item">
      <a href="<?php echo e(url('userinfo')); ?>"><strong>Build Profile</strong></a>

    </li>
    <li class="list-group-item">
      <a href="<?php echo e(url('jobs')); ?>"><strong><i  class="fa fa-tasks"></i> Jobs</strong></a>

    </li>
    <li class="list-group-item">
      <a href="#"><strong>CV/Resume</strong></a>

    </li>
  </li>
  <li class="list-group-item">
    <a href="<?php echo e(url('jobsapplied')); ?>"><strong>Jobs Applied</strong></a>

  </li>
  <li class="list-group-item">
    <a href="#"><strong>Jobs Sorted</strong></a>
  </ul>
</div>
