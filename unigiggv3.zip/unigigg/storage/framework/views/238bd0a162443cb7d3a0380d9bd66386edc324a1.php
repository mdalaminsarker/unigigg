<div class="jumbotron">


    <form  action="<?php echo e(url('userupdate')); ?>" method="POST">
      <div class="well">
        <span class="text-danger">Every Field is required</span>
      </div>
      <div class="md-col-6">
        <?php if(count($errors)>0): ?>
          <div class="alert alert-danger">
            <?php foreach($errors->all() as $error): ?>
              <p><?php echo e($error); ?></p>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
        <?php echo csrf_field(); ?>

        <div class="form-group">
          <?php echo Form::label('fname', 'First Name', ['class' => 'control-label']); ?>

          <?php echo Form::text('fname', null, ['class' => 'form-control']); ?>

        </div>
        <div class="form-group">
          <?php echo Form::label('lname', 'Last Name', ['class' => 'control-label']); ?>

          <?php echo Form::text('lname', null, ['class' => 'form-control']); ?>

        </div>
        <div class="form-group">
          <?php echo Form::label('area', 'Address', ['class' => 'control-label']); ?>

          <?php echo Form::text('area', null, ['class' => 'form-control']); ?>

          <span><small>Provide your living area in Dhaka</small></span>
        </div>
        <div class="form-group">
          <?php echo Form::label('post_code', 'post_code', ['class' => 'control-label']); ?>

          <?php echo Form::text('post_code', null, ['class' => 'form-control']); ?>

        </div>
        <div class="form-group">
          <?php echo Form::label('other', 'Other Details (if any)', ['class' => 'control-label']); ?>

          <?php echo Form::text('other', null, ['class' => 'form-control']); ?>

        </div>
        <div class="form-group">
          <?php echo Form::label('institute', 'Institute :', ['class' => 'control-label']); ?>

          <?php echo Form::text('institute', null, ['class' => 'form-control']); ?>

        </div>
        <div class="form-group">
          <?php echo Form::label('passing_date', 'Passing Year :', ['class' => 'control-label']); ?>

          <?php echo Form::date('passing_date', null, ['class' => 'form-control']); ?>

        </div>
        <div class="form-group">
          <?php echo Form::label('mobile', 'Contact No :', ['class' => 'control-label']); ?>

          <?php echo Form::text('mobile', null, ['class' => 'form-control']); ?>

        </div>
        <div class="form-group">
          <?php echo Form::label('universityId', 'University ID:', ['class' => 'control-label']); ?>

          <?php echo Form::text('universityId', null, ['class' => 'form-control']); ?>

        </div>
        <div class="form-group">
          <?php echo Form::label('NId', 'NID:', ['class' => 'control-label']); ?>

          <?php echo Form::text('NId', null, ['class' => 'form-control']); ?>

        </div>
        <div class="form-group">
          <?php echo Form::label('facebookId', 'Facebook ID:', ['class' => 'control-label']); ?>

          <?php echo Form::text('facebookId', null, ['class' => 'form-control']); ?>

        </div>
        <div class="form-group">
          <?php echo Form::label('LinkedInId', 'LinkedIn ID:', ['class' => 'control-label']); ?>

          <?php echo Form::text('LinkedInId', null, ['class' => 'form-control']); ?>

        </div>
        <div class="form-group">
          <?php echo Form::label('youtube', 'Video Profile', ['class' => 'control-label']); ?>

          <?php echo Form::text('youtube', null, ['class' => 'form-control']); ?>

        </div>


        <?php echo Form::submit('update', ['class' => 'btn btn-primary']); ?>

      </div>
  </form>
  </div>
