<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="name" content="First Online Youth Employment Platform in Bangladesh">

    <title>unigigg | Get Empowered | Get Hired</title>

    <!-- Fonts -->
    <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Raleway" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.4.0/css/font-awesome.min.css" rel='stylesheet' type='text/css'>
    <link href="https://fonts.googleapis.com/css?family=Lato:100,300,400,700" rel='stylesheet' type='text/css'>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <!-- Styles -->
    <link href="https://bootswatch.com/paper/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/material-design-iconic-font/2.2.0/css/material-design-iconic-font.min.css">
    <?php /* <link href="<?php echo e(elixir('css/app.css')); ?>" rel="stylesheet"> */ ?>
    <link href="<?php echo asset('css/sweetalert.css'); ?>" media="all" rel="stylesheet" type="text/css" />
    <style>
        body {
            font-family: 'Raleway';
            background-color: 	#f7f7f7;
            font-size: 16px;
            padding-top: 100px;

        }
        .center{
          text-align:center;;
        }
        .blue
        {
          background-color: #3b5998;
        }
        .white{
          background-color: #f7f7f7;
        }
        .textw
        {
          color:white;
        }
        .pad{
          padding:50px
        }
        .pb{
          padding-bottom: 100px;
        }

        .fa-btn {
            margin-right: 6px;
        }
        .textb{
          color:#3b5998;
        }
        .student{
          background-image: url(http://cdn1.theodysseyonline.com/files/2016/01/23/635891727862807756463608822_inspiration.jpg);
        }

    </style>
</head>
<body id="app-layout">
    <nav class="navbar navbar-default navbar-fixed-top">
        <div class="container">
            <div class="navbar-header">

                <!-- Collapsed Hamburger -->
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navbar-collapse">
                    <span class="sr-only">Toggle Navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>

                <!-- Branding Image -->
                <?php if(Auth::guest()): ?>

                  <a class="navbar-brand text-primary" href="<?php echo e(url('/')); ?>" >
                  <i class="fa fa-graduation-cap text-primary"></i>  unigigg <sub>alpha</sub>
                </a>

              <?php else: ?>

                <a class="navbar-brand text-primary" href="<?php echo e(url('/home')); ?>" >
                  <i class="fa fa-graduation-cap text-primary"></i>  unigigg<sub><small>alpha</small></sub>
                </a>
              <?php endif; ?>


            </div>

            <div class="collapse navbar-collapse" id="app-navbar-collapse">
                <!-- Left Side Of Navbar -->


                <!-- Right Side Of Navbar -->
                <ul class="nav navbar-nav navbar-right">
                    <!-- Authentication Links -->
                    <?php if(Auth::guest()): ?>

                      <ul class="nav navbar-nav">
                          <li ><a href="<?php echo e(url('/jobs')); ?>">Post A Job <sub><small>it's free</small></sub></a></li>
                          <li ><a href="<?php echo e(url('/recruiter')); ?>">Recruiter</a></li>
                          <li>
                          <a  href="#" class="dropdown-toggle  text-primary" data-toggle="dropdown" role="button" aria-expanded="false">
                            <i class="fa fa-btn fa-sign-up"></i> Sign Up <span class="caret"></span>
                          </a>
                          <ul class="dropdown-menu" role="menu">
                              <li><a href="<?php echo e(url('/register')); ?>"><i class="fa fa-btn fa-user"></i>Talent</a></li>
                              <li><a href="<?php echo e(url('employer/register')); ?>"><i class="fa fa-btn fa-users"></i>Employer</a></li>
                          </ul>
                          </li>
                      </ul>
                        <li class="divider"></li>
                        <li><a href="<?php echo e(url('/login')); ?>"> | <i class="fa fa-sign-in"></i> Sign in</a></li>


                        <!--
                        <li><a href="<?php echo e(url('/register')); ?>">Register</a></li>

                        <li><a href="<?php echo e(url('employer/register')); ?>">Employer Register</a></li>
                      -->
                    <?php else: ?>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                              <i class="fa fa-btn fa-user"></i>  <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                            </a>

                            <ul class="dropdown-menu" role="menu">
                                <li><a href="<?php echo e(url('/logout')); ?>"><i class="fa fa-btn fa-sign-out"></i>Sign Out</a></li>
                            </ul>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <?php echo $__env->yieldContent('content'); ?>



    <!-- JavaScripts -->

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="<?php echo asset('js/stellar.js'); ?>"></script>

    </script>
    <script src="https://cdn.jsdelivr.net/jquery.stellar/0.6.2/jquery.stellar.min.js">

    </script>

    </script>
    <?php /* <script src="<?php echo e(elixir('js/app.js')); ?>"></script> */ ?>
  </body>
</html>
