<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-primary">
                <div class="panel-heading"><h3 style="text-align:center;color:white;">Youth Employment Platform <img src="http://stepupforkin.org/wp-content/uploads/2013/10/news_3_icon.png" alt="" /></h3></div>

                <div class="panel-body">
                    <blockquote class="blockquote-reverse">
                      Find out what you like doing best, and get someone to pay you for it.
                      <small><cite title="Source Title">Katharine Whitehorn</cite></small>


                    </blockquote>
                </div>

            </div>
            <hr>
            <div class="col-md-6 ">
            <div class="panel panel-warning">
              <div class="panel-heading"><h2 style="color:white;">Recruiter <i class="fa fa-users fa-5px"></i></h2></div>
                <div class="panel-body">
                  Looking for Talents  ?
                  <h3><a href="<?php echo e(url('/employer/register')); ?>">Get started</a></h3>
                  <p>
                    Signup, it's free
                  </p>

                </div>
            </div>
            </div>

            <div class="col-md-6">
            <div class="panel panel-info">
              <div class="panel-heading"><h2 style="color:white;"> Talent <i class="fa fa-graduation-cap"></i></h2></div>
                <div class="panel-body">
                  Looking for Gigs ?
                  <h3><a href="<?php echo e(url('register')); ?>">Get started</a></h3>
                  <p>
                    Create a gig profile, it's free
                  </p>

                </div>

            </div>
          </div>
        </div>
    </div>
</div>
<?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>