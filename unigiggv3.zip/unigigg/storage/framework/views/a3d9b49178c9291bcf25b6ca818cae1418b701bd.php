<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">Welcome</div>

                <div class="panel-body">
                    To Unigigg.com
                </div>

            </div>
            <div class="col-md-6 ">
            <div class="panel panel-primary">
              <div class="panel-heading"><h2>Recruiter <i class="fa fa-users fa-5px"></i></h2></div>
                <div class="panel-body">
                  Looking for Talents  ?
                  <h3><a href="<?php echo e(url('/employer/egister')); ?>">Get started</a></h3>

                </div>
            </div>
            </div>

            <div class="col-md-6">
            <div class="panel panel-success">
              <div class="panel-heading"><h2> Talent <i class="fa fa-search"></i></h2></div>
                <div class="panel-body">
                  Looking for Gigs ?
                  <h3><a href="<?php echo e(url('register')); ?>">Get started</a></h3>

                </div>

            </div>
          </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>