

    <div class="panel panel-default">
      <div class="panel-heading"><a class="btn btn-primary btn-block btn-lg" data-toggle="collapse" href="#collapseExp">Add Experiences</a></div>
        <div id="collapseExp" class="panel-collapse collapse">
          <div class="panel-body">

    <?php echo Form::open(array('url' => '/experiencestore')); ?>



    <div class="form-group">
      <?php echo Form::label('exp_name', 'Title:', ['class' => 'control-label']); ?>

      <?php echo Form::text('exp_name', null, ['class' => 'form-control']); ?>

    </div>

    <div class="form-group">
      <?php echo Form::label('exp_start_date', 'Start Date:', ['class' => 'control-label']); ?>

      <?php echo Form::date('exp_start_date', null, ['class' => 'form-control']); ?>

    </div>
    <div class="form-group">
      <?php echo Form::label('exp_end_date', 'End Date:', ['class' => 'control-label']); ?>

      <?php echo Form::date('exp_end_date', \Carbon\Carbon::now(), ['class' => 'form-control']); ?>

    </div>
    <div class="form-group">
      <?php echo Form::label('exp_description', 'Tell Us Something About it:', ['class' => 'control-label']); ?>

      <?php echo Form::textarea('exp_description', null, ['class' => 'form-control' ,'row'=>'3',]); ?>

    </div>
    <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <?php foreach($errors->all() as $error): ?>
            <p><?php echo e($error); ?></p>
        <?php endforeach; ?>
    </div>
  <?php endif; ?>



    <?php echo Form::submit('Add', ['class' => 'btn btn-primary']); ?>


 <?php echo Form::close(); ?>


</div>
</div>
</div>
