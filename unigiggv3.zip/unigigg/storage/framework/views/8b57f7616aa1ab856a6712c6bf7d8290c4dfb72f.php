<?php $__env->startSection('content'); ?>
  <div class="container ">
    <div class="row">
      <?php echo $__env->make('layouts.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <div class="col-md-6">

          <h2 >Post Eccentric Jobs</h2>





        <?php echo Form::open(array('url' => '/eccentricJobspost')); ?>

        <?php if($errors->any()): ?>
          <div class="alert alert-danger">
            <?php foreach($errors->all() as $error): ?>
              <p><?php echo e($error); ?></p>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
        <div class="form-group">
          <?php echo Form::label('title', 'Job Title:', ['class' => 'control-label']); ?>

          <?php echo Form::text('title', null, ['class' => 'form-control']); ?>

        </div>
        <div class="form-group">

          <label for="type">Catagory</label>
          <select class="form-control" id="select" name="type">
            <option value="Tution">Tution</option>
            <option value="Assignment">Assignment Help</option>
            <option value="Others">Others</option>

          </select>

        </div>
        <div class="form-group">
          <?php echo Form::label('description', 'Job Description:', ['class' => 'control-label']); ?>

          <?php echo Form::textarea('description', null, ['class' => 'form-control', 'row'=>2]); ?>

        </div>
        <div class="form-group">

          <label for="type">Offering(TK):</label>
          <select class="form-control" id="select" name="offering">
            <option value="500-1000">500-1000</option>
            <option value="1000-3000">1000-3000</option>
            <option value="3000-5000">3000-5000</option>
            <option value="5000-10000">5000-10000</option>
          </select>

        </div>
        <div class="form-group">
          <?php echo Form::label('area', 'Location:', ['class' => 'control-label']); ?>

          <?php echo Form::text('area', null, ['class' => 'form-control']); ?>

        </div>
        <div class="form-group">
          <?php echo Form::label('university', 'University', ['class' => 'control-label']); ?>

          <?php echo Form::text('university', null, ['class' => 'form-control']); ?>

          <small>Choose Preferred University, If you have any. <span class="text-danger">Please insert full University name</span></small>
        </div>
        <div class="form-group">
          <?php echo Form::submit('Post Job', array( 'class'=>'btn btn-success form-control' )); ?>

        </div>

        <?php echo Form::close(); ?>






      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>