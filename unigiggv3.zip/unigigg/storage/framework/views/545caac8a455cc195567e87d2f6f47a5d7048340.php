<div >


  <h4>Your interest</h4>

  <?php foreach($interest as $interests): ?>
    <div class="col-md-8 col-md-8-offset-1 well-sm ">
      <strong>  Interest : </strong><?php echo e($interests->interest_name); ?>

        <form action="<?php echo e(url('interest',$interests->interest_id)); ?>" method="POST">
          <?php echo csrf_field(); ?>

          <button type="submit" class="btn btn-danger pull-right">
            <i class="fa fa-trash"></i> Delete
          </button>
        </form>
    </div>

  <?php endforeach; ?>

</div>
