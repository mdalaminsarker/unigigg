<div>


  <!--about your self -->

  <h3>About You</h3>
  <?php foreach($funs as $fun): ?>
    <p>
      <?php echo e($fun->fun_facts); ?>

    </p>
    <p>
      <?php echo e($fun->inspiration_qot); ?>

    </p>
    <p>
      <?php echo e($fun->Why_you); ?>

    </p>
    <p>
      <?php echo e($fun->Why_not_you); ?>

    </p>

  <?php endforeach; ?>
</div>
