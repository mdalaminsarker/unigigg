<div >
  <h4>References</h4>
  <button  class="btn btn-success" type="button" name="button">Verify</button>
</div>

<?php foreach($refs as $ref): ?>



  <table class="table table-bordered">
   <thead class="text-primary">
     <th>
       Referred By

     </th>
     <th>
       Reference
     </th>
     <th>
       Contact
     </th>
     <th>
       verification
     </th>
     <th>
       Delete
     </th>

   </thead>
   <tbody>
     <tr>
       <td>
         <?php echo e($ref->referred_by); ?>

       </td>
       <td>
        <?php echo e($ref->reference_description); ?>

       </td>
       <td>
         <?php echo e($ref->referee_number); ?>

       </td>
       <?php if($ref->verified===0): ?>
       <td>
         <i class="fa fa-thumbs-o-down fa-3x"></i>
          </td>
       <?php else: ?>
         <td>
              <i class="medium material-icons">verified_user</i>
         </td>
     <?php endif; ?>
       <td>
         <form action="<?php echo e(url('refdelete',$ref->id)); ?>" method="POST">
           <?php echo csrf_field(); ?>

           <button type="submit" class="btn btn-danger ">
             <i class="fa fa-cross"></i> Delete
           </button>
         </form>
       </td>

     </tr>
   </tbody>
  </table>


<?php endforeach; ?>
