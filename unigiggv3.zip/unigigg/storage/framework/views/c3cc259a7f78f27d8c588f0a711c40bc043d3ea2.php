<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row">
    <?php echo $__env->make('layouts.menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="col-md-10 ">
      <table class="table table-striped">
        <thead>
          <th>
            Jobs
          </th>
          <th>
            Job Posted By
          </th>
          <th>
            Last date of Application
          </th>


        </thead>

        <?php foreach($applied as $apply): ?>
            <?php if($apply->user_id===Auth::user()->id): ?>



        <tbody>
          <tr>
            <td>
              <?php echo e($apply->job_name); ?>


            </td>
            <td>
              <?php echo e($apply->company_name); ?>

            </td>
            <td>
                <?php echo e($apply->job_last_date_application); ?>

            </td>
            <td>
              <form action="<?php echo e(url('removeapplication',$apply->applied_id)); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <button type="submit" class="btn btn-danger">
                  <i class="fa fa-user"></i> Remove
                </button>
              </form>
            </td>

          </tr>
        </tbody>
<?php endif; ?>
        <?php endforeach; ?>

      </table>



      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>