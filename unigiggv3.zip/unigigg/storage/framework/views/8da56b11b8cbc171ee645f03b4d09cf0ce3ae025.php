<footer class="footer" style="background-color:#ffffff; padding:26px">
  <div class="container">
    <div class="col-md-4">
      <img src="/images/unigig-logo.png" alt="" height="100px" width="100px" />
      <p>
      We are on a mission to help employers attract young talent, and for our friends to find the right internship and job opportunities.
      </p>

    </div>
    <div class="col-md-4">
      <br>
      <h5><a href="<?php echo e(url('about')); ?>">About Us</a></h5>
      <h5><a href="#">Faqs</a><br></h5>
      <h5><a href="#">Terms and Conditions</a></h5>
      <h5><a href="#">Blog</a></h5>
      <h5><a href="<?php echo e(url('recruiter')); ?>">Recruiter</a></h5>
      <h5><a href="<?php echo e(url('talent')); ?>">Talent</a></h5>

    </div>
    <div class="col-md-4">
      <h4 class="text-primary">Contact</h4>
      <p>
        <strong>Call Us <i class="fa fa-phone fa-1x"></i></strong>:<br> +880-1987847548   <strong class="pull-right"><a href="https://www.facebook.com/unigigg"  target="_blank"><i class="fa fa-facebook fa-3x"></i></a></strong>
        <br><strong>Meet Us <i class="fa fa-map-marker fa-1x"></i></strong>:<br> House-12,Road-5,<br> Block-C,Section-2 <br>
        Mirpur,Dhaka-1216 <br>

      </p>

    </div>


  </div>
</footer>
