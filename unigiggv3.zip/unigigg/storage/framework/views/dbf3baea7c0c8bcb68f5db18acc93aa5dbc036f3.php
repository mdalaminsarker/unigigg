<?php $__env->startSection('content'); ?>
  <div class="container">
    <div class="row">
      <?php echo $__env->make('layouts.emmenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <div class="col-md-10 ">
        <div class="panel panel-primary">
          <div class="panel-heading">Employer Dashboard</div>

          <div class="panel-body">
            <div>

              <div>


              <?php if(count($images)>0): ?>
                <?php foreach($images as $image): ?>
                  <img src="<?php echo '/images/'.$image->filePath; ?>" alt="propic" height="200px" width="200px" style="border-radius:30%;" />

                <?php endforeach; ?>
              <?php else: ?>
                <img src="https://minions-funmobility.netdna-ssl.com/wp-content/uploads/2015/05/signup-after-img1.jpg" alt="Pro Pic" height="200px" width="200px"/>

              <?php endif; ?>
                </div>

            <h3>Welcome <strong class="primary"><?php echo e(Auth::user()->name); ?>

              </strong> The Recruiter</h3>  
            </div>

            <div class="Jumbotron">
              <?php if(count($eminfos)>0): ?>
                <div class="jumbotron">


                  <h4>Company Details</h4><button type="button" name="button" class="btn btn-primary"><i class="fa fa-edit"></i> Edit</button>

                  <?php foreach($eminfos as $eminfo): ?>
                    <p>

                      <p>Company Name: <?php echo e($eminfo->company_name); ?></p>
                      <p>Company Type: <?php echo e($eminfo->company_type); ?></p>
                      <p>Company Size: <?php echo e($eminfo->company_size); ?></p>
                      <p>Company Description: <?php echo e($eminfo->company_description); ?></p>

                    </p>

                  <?php endforeach; ?>

                </div>
              <?php endif; ?>




            </div>

          </div>
        </div>
      </div>
    </div>
  </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>