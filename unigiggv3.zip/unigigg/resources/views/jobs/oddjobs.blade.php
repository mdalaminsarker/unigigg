@extends('layouts.app')
@section('content')
  <div class="container">
    <div class="row">
      <a href="{{url('home')}}"><h4 class="text-primary"><i class="fa fa-arrow-left"></i> Go Back </h4></a>
      @if(count($oddjobs)>0)

        @foreach($oddjobs as $jobs)
          <div class="panel panel-default">
            <div class="panel-heading">
              {{$jobs->title}}
            </div>
            <div class="panel-body">
              <h5>{{$jobs->type}}</h5>
              <p>
                {{$jobs->description}}
              </p>
              <h5>{{$jobs->offering}}</h5>

            </div>
            <div class="panel-footer">
              <button type="submit" name="button" class="btn btn-success">Apply</button>
            </div>

          </div>
        @endforeach

      @endif


    </div>
  </div>
@endsection
