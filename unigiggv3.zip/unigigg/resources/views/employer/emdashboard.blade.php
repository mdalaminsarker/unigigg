@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
      @include('layouts.emmenu')
        <div class="col-md-10 ">
            <div class="panel panel-primary">
                <div class="panel-heading">Employer Dashboard</div>

                <div class="panel-body">
                  <div class="jumbotron">

                    <img src="https://minions-funmobility.netdna-ssl.com/wp-content/uploads/2015/05/signup-after-img1.jpg" alt="Pro Pic" height="200px" width="200px"/>

                    Welcome <strong class="primary">{{ Auth::user()->name }}
                    </strong> The Recruiter
                  </div>

                  <div class="Jumbotron">
                    @if(count($eminfos)>0)
                      <div class="jumbotron">


                        <h4>Company Details</h4><button type="button" name="button" class="btn btn-primary"><i class="fa fa-edit"></i> Edit</button>

                        @foreach ($eminfos as $eminfo)
                          <p>

                              <p>Company Name: {{$eminfo->company_name}}</p>
                              <p>Company Type: {{$eminfo->company_type}}</p>
                              <p>Company Size: {{$eminfo->company_size}}</p>
                              <p>Company Description: {{$eminfo->company_description}}</p>

                          </p>

                        @endforeach

                    </div>
                      @endif




                  </div>

                </div>
            </div>
        </div>
    </div>
</div>
@endsection
