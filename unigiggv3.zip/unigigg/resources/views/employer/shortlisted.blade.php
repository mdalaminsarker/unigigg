@extends('layouts.app')

@section('content')
  <div class="container ">
    <div class="row">
      @include('layouts.emmenu')
      <div class="col-md-10">
        <div class="well">
          <h4 class="text-info">Shortlisted Candidates</h4>
        </div>



        <table class="table table-striped">
          <thead>
            <th>
              Candidate Name
            </th>
            <th>
              Shortlisted For
            </th>
            <th>
              Profile View
            </th>
            <th>
              Remove
            </th>
          </thead>
            @foreach( $shortlisted as $shortlist )
          <tbody>
            <tr>
              <td>
                {{$shortlist->user_id}} {{$shortlist->lname}}
              </td>
              <td>
                {{$shortlist->job_name}}
              </td>
              <td>
                <button type="button" name="button">View Profile</button>
              </td>
              <td>
                <form action="{{url('shortlist',$shortlist->em_shortlist_id)}}" method="POST">
                  {!! csrf_field() !!}
                  <button type="submit" class="btn btn-info btn-sm btn-block-sm">
                    <i class="fa fa-user"></i> Remove
                  </button>
                </form>
              </td>
            </tr>
          </tbody>

        </table>
        @endforeach

      </div>
    </div>
  </div>
