@extends('layouts.app')

@section('content')
  <div class="container ">
    <div class="row">
      @include('layouts.emmenu')
      <div class="col-md-6">
        <div class="well">
          <h4 class="text-info">Post a Job</h4>
        </div>
        <div class="col-md-8">
          @if(count($postedjobs)>0)

              @foreach($postedjobs as $jobs)

                  <div class="panel panel-primary">
                    <div class="panel-heading">
                      <h3 class="panel-title">{{$jobs->job_name}}</h3>
                    </div>
                    <div class="panel-body">
                      <Type: {{$jobs->job_type}}</li>
                      <li>Location: {{$jobs->job_location}}</li>
                      <li>Salary: {{$jobs->job_salary}}</li>
                      <div class="well">
                        Description: {{$jobs->job_description}}
                        {{$jobs->job_reqs}}
                      </div>


                    </div>
                  </div>


              @endforeach

            @endif



        </div>
