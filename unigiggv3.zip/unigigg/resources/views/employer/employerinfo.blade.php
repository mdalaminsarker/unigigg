@extends('layouts.employerapp')

@section('content')
  <div class="container ">
    <div class="row">
      @include('layouts.emmenu')
      <div class="col-md-6">
        <div class="well">
          <h4 class="text-info">Build Company Profile</h4>
        </div>
        <h1 class="well well-lg">Basic info</h1>
        <div class="container">

          <div class="col-md-6">
            {!! Form::open(array('url' => '/employerinfo')) !!}

            <div class="form-group">
                {!! Form::label('company_name', 'Company Name:') !!}
                {!! Form::text('company_name', null, ['class'=>'form-control']) !!}
            </div>

            <div class="form-group">
                {!! Form::label('company_type', 'Type:') !!}
                {!! Form::text('company_type', null, ['class'=>'form-control'] ) !!}
            </div>
            <div class="form-group">
                {!! Form::label('company_size', 'Size:') !!}
                {!! Form::text('company_size', null, ['class'=>'form-control'] ) !!}
            </div>

            <div class="form-group">
                {!! Form::label('company_description', 'Description:') !!}
                {!! Form::textarea('company_description', null, ['class'=>'form-control', 'rows'=>2] ) !!}
            </div>


            <div class="form-group">
                {!! Form::submit('Save', array( 'class'=>'btn btn-success form-control' )) !!}
            </div>

            {!! Form::close() !!}
            </div>


        </div>
      </div>
      </div>
      </div>

    @endsection
