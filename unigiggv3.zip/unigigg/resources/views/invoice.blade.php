<!DOCTYPE html>
<html lang="en">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
  @foreach($data as $user)
    <title>{{$user->name}}</title>
    <style>
    #header {
        background-color:black;
        color:white;
        text-align:center;
        padding:5px;
    }
    #nav {
        line-height:30px;
        background-color:#eeeeee;
        height:300px;
        width:100px;
        float:left;
        padding:5px;
    }
    #section {
        width:350px;
        float:left;
        padding:10px;
    }
    #footer {
        background-color:black;
        color:white;
        clear:both;
        text-align:center;
        padding:5px;
    }
    </style>


  </head>
  <body >

    <main  >
      <div id="details" class="right">
        <div id="invoice">
          <h1>INVOICE {{ $invoice }}</h1>
          <hr>
          <div class="date">Date of Invoice: {{ $date }}</div>
        </div>
      </div>
      <table border="0" cellspacing="2" cellpadding="3">
        <thead style="color:green;">
          <tr>
            <th class="no">id</th>
            <th class="desc">Name</th>
            <th class="unit">Email</th>

          </tr>
        </thead>

        <tbody style="color: blue;">
          <tr>

            <td class="no">{{ $user->id }}</td>
            <td class="desc">{{ $user->name }}</td>
            <td class="unit">{{ $user->email }}</td>




          </tr>

        </tbody>
      @endforeach

    </table>
    <div id="header">
      <h1>City Gallery</h1>
    </div>

    <div id="nav">
      London<br>
      Paris<br>
      Tokyo
    </div>

    <div id="section">
      <h1>London</h1>
      <p>London is the capital city of England. It is the most populous city in the United Kingdom,
        with a metropolitan area of over 13 million inhabitants.</p>
        <p>Standing on the River Thames, London has been a major settlement for two millennia,
          its history going back to its founding by the Romans, who named it Londinium.</p>
        </div>

        <div id="footer">
          Copyright © W3Schools.com
        </div>

      </body>
      </html>
