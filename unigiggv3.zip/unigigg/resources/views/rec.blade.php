@extends('layouts.app')

@section('content')
  <div class="container">
      <div class="row">
        <div style="text-align:center">


        <h1>Recruitment, Made Easy</h1>
        <img src="http://media.gallup.com/GMJ/art/20051110_2_2.gif" alt="" />
      </div>
    </div>
  m1</div>
  @include('layouts.footer')
  @endsection
