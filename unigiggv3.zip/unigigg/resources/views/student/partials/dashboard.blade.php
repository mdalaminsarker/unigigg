<div class="container">
  <div class="row">
    @include('layouts.menu')

    <div class="col-md-10 ">
      <div class="panel panel-primary">
        <div class="panel-heading">Dashboard</div>

        <div class="panel-body">
          <h4 class="well">Welcome onboard <strong>{{Auth::user()->name}}</strong>   </h4>
          <div class="col-md-5">


          @if(count($images)>0)
            @foreach($images as $image)
              <img src="{!!'/images/'.$image->filePath !!}" alt="propic" height="200px" width="200px" style="border-radius:30%;" />

            @endforeach
          @else
            <img src="https://minions-funmobility.netdna-ssl.com/wp-content/uploads/2015/05/signup-after-img1.jpg" alt="Pro Pic" height="200px" width="200px"/>

          @endif
            </div>



          <div class="jumbotron">
            <p class="text-primary">

            </p>

            <p>
              @if(count($infos)>0)
                @foreach ($infos as $users)
                  <p>
                    <h6>Phone : {{$users->mobile}}<i class="fa fa-check"></i></h6>
                    <h6>Institute: {{$users->institute}}</h6>
                    <h6>NID : {{$users->NId}}</h6>
                  </p>
                  <h5>University ID :{{$users->universityId}} <i class="fa fa-check"></i></h5>
                  Facebook: Id:
                  <a href="{{$users->facebookId}}" target="_blank">{{$users->fname}}</a> <i class="fa fa-check"></i>
                @endforeach
              @endif


            </p>
          </div>
          <!-- Skills-->
          @if(count($skill)>0)
            <div class="jumbotron">


              <h4>Your Skills</h4>

              @foreach ($skill as $skills)
                <p>
                  <ul>
                    <li>{{$skills->skill_name}}--->{{$skills->skill_level}}</li>
                  </ul>
                </p>

              @endforeach

          </div>
            @endif


          <!-- interest-->
            @if(count($interest)>0)
          <div class="jumbotron">


            <h4>Your interest</h4>

              @foreach ($interest as $interests)
                <p>
                  <ul>
                    <li>{{$interests->interest_name}}</li>
                  </ul>
                </p>

              @endforeach

          </div>
            @endif

          @if(count($hobbies)>0)
          <!-- Hobbies-->
          <div class="jumbotron">


            <h4>Your Hobbies</h4>

              @foreach ($hobbies as $hobby)
                <p>
                  <ul>
                    <li>{{$hobby->hobbies_name}} --> {{$hobby->hobbies_related_work}}</li>
                  </ul>
                </p>

              @endforeach

          </div>
          @endif

          @if(count($education)>0)
            <div class="jumbotron">


              <h5>Education</h5>


              <table class="table table-striped table-hover">
                <thead class="text-primary">
                  <tr>
                    <th>
                      Degree Name
                    </th>
                    <th>
                      Degree Type
                    </th>
                    <th>
                      Starting Date
                    </th>
                    <th>
                      Passing Date
                    </th>
                    <th>
                      Institute
                    </th>
                    <th>
                      Result
                    </th>
                    <tr>
                    </thead>
                  </tbody>
                  @foreach ($education as $edu)
                    <tr>
                      <td>
                        {{$edu->Degree_name}}
                      </td>
                      <td>
                        {{$edu->Degree_type}}
                      </td>
                      <td>
                        {{$edu->Degree_start_date}}
                      </td>
                      <td>
                        {{$edu->Degree_end_date}}
                      </td>
                      <td>
                        {{$edu->Degree_institute}}
                      </td>
                      <td>
                        {{$edu->Degree_result}}
                      </td>
                    </tr>
                  </tbody>
                </table>

              @endforeach
            </div>
          @endif
          @if(count($experiences)>0)
            <div class="jumbotron">


              <h5>Experience</h5>
              <table class="table table-striped table-hover">
                <thead>
                  <tr>
                    <th>
                      Title
                    </th>

                    <th>
                      Starting Date
                    </th>
                    <th>
                      End Date
                    </th>
                    <th>
                      Description
                    </th>

                    <tr>
                    </thead>
                    <tbody>
                      @foreach ($experiences as $experience)
                        <tr>
                          <td>
                            {{$experience->exp_name}}
                          </td>

                          <td>
                            {{$experience->exp_start_date}}
                          </td>
                          <td>
                            {{$experience->exp_end_date}}
                          </td>
                          <td>
                            {{$experience->exp_description}}
                          </td>
                        @endforeach
                      </tbody>
                    </table>

                  </div>
                @endif

                @if(count($extracs)>0)
                  <div class="jumbotron">


                    <h5>Extra Curricular Activities</h5>
                    <table class="table table-striped table-hover">
                      <thead>
                        <tr>
                          <th>
                            Title
                          </th>

                          <th>
                            Starting Date
                          </th>
                          <th>
                            End Date
                          </th>
                          <th>
                            Description
                          </th>

                          <tr>
                          </thead>
                          <tbody>
                            @foreach ($extracs as $excc)
                              <tr>
                                <td>
                                  {{$excc->excc_name}}
                                </td>

                                <td>
                                  {{$excc->excc_start_date}}
                                </td>
                                <td>
                                  {{$excc->excc_end_date}}
                                </td>
                                <td>
                                  {{$excc->excc_description}}
                                </td>
                              @endforeach
                            </tbody>
                          </table>
                        </div>
                      @endif
                      @if(count($funs)>0)
                        <div class="jumbotron">


                          <!--about your self -->

                          <h3>About You</h3>
                          @foreach($funs as $fun)
                            <p>
                              {{$fun->fun_facts}}
                            </p>
                            <p>
                              {{$fun->inspiration_qot}}
                            </p>
                            <p>
                              {{$fun->Why_you}}
                            </p>

                          @endforeach
                        </div>
                      @endif

                      <!--about your self ends-->

                    </div>

                  </div>
                </div>





              </div>
            </div>
