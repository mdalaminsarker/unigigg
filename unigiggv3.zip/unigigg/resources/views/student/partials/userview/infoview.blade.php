<div >


  <p>
    @if(count($infos)>0)

      @foreach ($infos as $users)
        <p>

            <iframe width="400" height="250" src="https://www.youtube.com/embed/{{$users->youtube}}
            " frameborder="0" allowfullscreen></iframe>'
            <hr>
          

          <hr>
          <h6>Phone : {{$users->mobile}}</h6>
          <h6>Institute: {{$users->institute}}</h6>
          <h6>NID : {{$users->NId}}</h6>
        </p>
        <p>
        <h5>University ID :{{$users->universityId}}</h5>
        Facebook: Id:
        <a href="{{$users->facebookId}}" target="_blank">{{$users->fname}}</a><br>
          <button type="submit" class="btn btn-primary" data-toggle="modal" data-target="#myModaluserinfo" ><i class="fa fa-edit"></i> Edit</button>
          <hr>
          <form action="{{url('pdf',$users->user_id)}}" method="POST">
            {!! csrf_field() !!}
            <button type="submit" class="btn btn-info">
              <i class="fa fa-tasks"></i> Generate CV
            </button>
          </form>
          <hr>
      @endforeach

  @endif



  </p>
  <!-- Modal -->
  <div class="modal fade" id="myModaluserinfo" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
          <h4 class="modal-title" id="myModalLabel">Update Information</h4>
        </div>
        <div class="modal-body">
          @include('student.partials.update.userinfoupdate')
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>

        </div>
      </div>
    </div>
  </div>
  <!-- Modal ends -->
</div>
