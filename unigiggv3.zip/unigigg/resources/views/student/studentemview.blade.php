@extends('layouts.app')

@section('content')
  <div class="container ">
    <div class="row">

      <div class="col-md-10">
        <a href="{{url('home')}}">Go Back</a>
        <div class="panel panel-info" >


      @foreach($profile as $view )
        <div class="panel-heading">
          <h3 style="color:white;">{{$view->fname}}   {{$view->lname}}</h3>

      </div>
      <div class="panel-body">
        <div class="well-info">

            <p>
              {{$view->institute}}
            </p>
          <p>
            {{$view->NId}}
          </p>
        </div>
      @endforeach
      @foreach($skill as $skills)
        <div class="well">
          {{$skills->skill_name}}
        </div>

      @endforeach
      @foreach($education as $edu)
        <div class="well">
          {{$edu->Degree_name}}
          {{$edu->Degree_result}}
        </div>

      @endforeach




      </div>
      <div class="panel-footer">
        <button type="button" name="button">Shortlist</button>
      </div>
    </div>

  </div>
