@extends('layouts.app')

@section('content')
  <div class="container ">
    <div class="row">

      <div class="col-md-10">
        <div class="panel panel-info">


      @foreach($profile as $view )
        <div class="panel-heading">
          <h3 class="inverse">{{$view->fname}}   {{$view->lname}}</h3>

      </div>
      <div class="panel-body">
        <div class="well-info">

            {{$view->institute}}<br>
            {{$view->NId}}<br>
        </div>

          @endforeach
          <p>
          <div class="well">
            @foreach($hobbies as $hobby )
              {{$hobby->hobbies_name}}
              <p>
                {{$hobby->hobbies_related_work}}
              </p>
            @endforeach</p>
          </div>
      </div>
      <div class="panel-footer">
        <button type="button" name="button">Shortlist</button>
      </div>
    </div>
  </div>
