<div class="panel panel-default">
  <div class="panel-heading"><a data-toggle="collapse" href="#collapse5">Upload Profile Pic</a></div>
  <div id="collapse5" class="panel-collapse collapse">
      <div class="panel-body">
      {!! Form::open(array('url' => '/imagestore','files'=>true)) !!}

      <div class="alert alert-danger">
          @foreach($errors->all() as $error)
              <p>{{ $error }}</p>
          @endforeach
      </div>

      <div class="form-group">
          {!! Form::label('filePath', 'Choose profile Image') !!}
          {!! Form::file('filePath') !!}
      </div>

      <div class="form-group">
          {!! Form::submit('upload', array( 'class'=>'btn btn-success form-control' )) !!}
      </div>

      @if(isset($success))
          <div class="alert alert-success"> {{$success}} </div>
      @endif

      {{!! Form::close() !!}}
      </div>
    </div>
  </div>
