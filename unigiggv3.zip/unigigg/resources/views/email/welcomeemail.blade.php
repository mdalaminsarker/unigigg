<!DOCTYPE html>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <h3>Welcome to Unigigg.com
        {{$user->name}}
   <h3>
      <p>
        Welcome to the first youth employment platform of Bangladesh
      </p>




  </body>
</html>
