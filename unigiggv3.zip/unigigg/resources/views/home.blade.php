@extends('layouts.app')

@section('content')
  @if(Auth::user()->type === 1)
  @include('student.partials.dashboard');
@else
  @include('employer.emdashboard');
@endif
@endsection
